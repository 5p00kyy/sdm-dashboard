# Public orchestration API for the SDM workflow.

run_fast_sdm <- function(species = "Piper aduncum", occurrence_file = "presence_data.csv", worldclim_dir = "Worldclim",
                         selected_biovars = c(1, 4, 6, 12, 15, 18), projection_extent = c(112, 155, -45, -10),
                         training_extent = NULL, background_n = 10000, min_source_records = 15, merge_small_sources = TRUE,
                         thinning_method = "cell", spthin_distance_km = 50, model_type = "glm", n_bags = 100,
                         ensemble_weighting = "tss", tss_threshold = 0.6,
                         include_quadratic = TRUE, threshold = 0.5, aggregation_factor = 1,
                         cv_folds = 5, n_cores = NULL, allow_download = TRUE, worldclim_res = 10,
                         use_elevation = FALSE, elevation_demtype = "COP90", opentopo_api_key = NULL,
                         use_soil = FALSE, soil_depth = 30,
                         selected_soil_vars = soilgrids_default_vars, covariate_cache_dir = "covariates",
                         boundary_path = NULL,
                         use_microclimate = FALSE, modis_year_range = c(2020, 2023),
model_types = c("glm", "ranger", "maxent", "rangebag"),
                          output_uncertainty = TRUE,
                          maxent_linear = TRUE, maxent_quadratic = TRUE, maxent_product = FALSE,
                          maxent_hinge = TRUE, maxent_threshold = FALSE, maxent_beta = 1.0,
                          cv_method = "random", n_blocks = 5, block_method = "kmeans",
                          min_points_per_block = 20,
                          enable_tuning = FALSE,
                          d = 1, force_2d = FALSE,
                         output_dir = "outputs", seed = 42, log_fun = NULL, progress_fun = NULL) {

  d <- as.integer(d)
  if (is.na(d) || d < 1 || d > 2) {
    if (!is.null(log_fun)) log_fun("WARNING: d must be 1 or 2, setting to 1")
    d <- 1
  }
  ensure_sdm_packages(c("terra", "dismo", "raster"), n_cores = n_cores)
  n_cores <- configure_parallel(n_cores, log_fun = log_fun)
  projection_extent <- validate_extent(as.numeric(projection_extent), "projection_extent")
  if (!is.null(training_extent)) training_extent <- validate_extent(as.numeric(training_extent), "training_extent")
  selected_biovars <- validate_biovars(selected_biovars)
  threshold <- normalize_threshold(threshold)
  aggregation_factor <- as.integer(aggregation_factor)
  if (is.na(aggregation_factor) || aggregation_factor < 1) aggregation_factor <- 1
  selected_soil_vars <- unique(as.character(selected_soil_vars))
  selected_soil_vars <- selected_soil_vars[nzchar(selected_soil_vars)]
  model_type <- match.arg(model_type, c("glm", "rangebag", "ensemble"))
  valid_model_types <- c("glm", "ranger", "maxent", "gam", "rangebag")
  model_types <- unique(as.character(model_types[model_types %in% valid_model_types]))
  if (length(model_types) < 1) model_types <- c("glm")

  cv_folds <- as.integer(cv_folds)
  if (is.na(cv_folds) || cv_folds < 2) cv_folds <- 5
  seed <- as.integer(seed)
  if (is.na(seed) || seed < 1) seed <- 42
  start_time <- Sys.time()
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  dir.create(covariate_cache_dir, recursive = TRUE, showWarnings = FALSE)

  boundary <- NULL
  if (!is.null(boundary_path) && nzchar(boundary_path)) {
    log_message(log_fun, "Loading boundary from: ", boundary_path)
    boundary <- load_boundary_vector(boundary_path, "EPSG:4326")
  }

  progress_step(progress_fun, 0.08, "Cleaning occurrence data")
  cleaned <- clean_occurrences(occurrence_file, min_source_records = min_source_records, merge_small_sources = merge_small_sources, log_fun = log_fun)
  occ <- cleaned$occ
  if (is.null(training_extent)) training_extent <- make_training_extent(occ, buffer = 2)
  log_message(log_fun, "Training extent: ", paste(training_extent, collapse = ", "))
  log_message(log_fun, "Projection extent: ", paste(projection_extent, collapse = ", "))

  progress_step(progress_fun, 0.18, "Loading and scaling environmental covariates")
  env <- load_environment(
    worldclim_dir = worldclim_dir,
    selected_biovars = selected_biovars,
    training_extent = training_extent,
    projection_extent = projection_extent,
    aggregation_factor = aggregation_factor,
    allow_download = allow_download,
    worldclim_res = worldclim_res,
    log_fun = log_fun,
    n_cores = n_cores,
    use_elevation = use_elevation,
    elevation_demtype = elevation_demtype,
    opentopo_api_key = opentopo_api_key,
    use_soil = use_soil,
    soil_depth = soil_depth,
    selected_soil_vars = selected_soil_vars,
    covariate_cache_dir = covariate_cache_dir,
    boundary = boundary,
    use_microclimate = use_microclimate,
    modis_year_range = modis_year_range
  )

  thinning_method <- match.arg(thinning_method, c("none", "cell", "distance"))
  if (is.null(spthin_distance_km) || is.na(spthin_distance_km) || spthin_distance_km < 1) spthin_distance_km <- 50
  if (thinning_method == "cell") {
    progress_step(progress_fun, 0.08, "Thinning by raster cell")
    occ <- thin_occurrences_by_cell(occ, env$env_train_scaled[[1]], by_source = FALSE, log_fun = log_fun)
  } else if (thinning_method == "distance") {
    progress_step(progress_fun, 0.08, "Distance-based spatial thinning (spThin)")
    occ <- thin_occurrences_by_distance(occ, min_distance_km = spthin_distance_km, reps = 100, seed = seed, log_fun = log_fun)
  }

  spatial_fold_id <- NULL
  if (cv_method == "spatial_block" && cv_folds > 1) {
    progress_step(progress_fun, 0.20, "Creating spatial block CV folds")
    fold_result <- create_cv_folds(occ, env$env_train_scaled, cv_method = "spatial_block",
                                     n_blocks = n_blocks, block_method = block_method,
                                     min_points_per_block = min_points_per_block, seed = seed)
    spatial_fold_id <- fold_result$fold_id
    cv_folds <- fold_result$k
    log_message(log_fun, "Created ", cv_folds, " spatial blocks for CV")
  }

  if (enable_tuning && length(model_types) == 1) {
    tuning_config <- get_default_tuning_config(model_types[1])
    if (length(tuning_config) > 0) {
      progress_step(progress_fun, 0.21, "Running hyperparameter tuning")
      tune_result <- tune_model(model_types[1], occ, env$env_train_scaled, background_n,
                                 cv_folds = cv_folds, seed = seed, n_cores = n_cores,
                                 tuning_config = tuning_config, log_fun = log_fun)
      if (!is.null(tune_result)) {
        log_message(log_fun, "Best tuning params: ", paste(names(tune_result$best_params), "=",
                  unlist(tune_result$best_params), collapse = ", "))
      }
    }
  }

  progress_step(progress_fun, 0.22, "Fitting model")

  if (model_type == "glm") {
    log_message(log_fun, "Using GLM model")
    fit <- fit_fast_sdm(occ, env$env_train_scaled, background_n, include_quadratic, cv_folds, seed, n_cores, log_fun,
                       cv_method = cv_method, spatial_fold_id = spatial_fold_id)
    fit$model_type <- "glm"
  } else if (model_type == "rangebag") {
    log_message(log_fun, "Using Rangebagging model (d=", d, ", force_2d=", force_2d, ")")
    fit <- fit_rangebag_sdm(occ, env$env_train, env$env_train_scaled, background_n, n_bags, cv_folds, seed, n_cores, log_fun, threshold, d = d, force_2d = force_2d,
                           cv_method = cv_method, spatial_fold_id = spatial_fold_id)
    fit$model_type <- "rangebag"
  } else if (model_type == "ensemble") {
    log_message(log_fun, sprintf("Using N-Model Ensemble (%s), d=%d, force_2d=%s", paste(model_types, collapse = "+"), d, force_2d))
    fit <- fit_ensemble_sdm(occ, env$env_train, env$env_train_scaled, background_n,
                            include_quadratic, n_bags, cv_folds,
                            seed, n_cores, ensemble_weighting, tss_threshold, log_fun, threshold,
                            d = d, force_2d = force_2d,
                            model_types = model_types, output_uncertainty = output_uncertainty,
                            maxent_linear = maxent_linear, maxent_quadratic = maxent_quadratic,
                            maxent_product = maxent_product, maxent_hinge = maxent_hinge,
                            maxent_threshold = maxent_threshold, maxent_beta = maxent_beta,
                            cv_method = cv_method, spatial_fold_id = spatial_fold_id)
    fit$model_type <- "ensemble"
  }

  progress_step(progress_fun, 0.24, "Predicting projection raster")
  base_name <- paste0(safe_slug(species), "_", format(Sys.time(), "%Y%m%d_%H%M%S"))
  output_tif <- file.path(output_dir, paste0(base_name, "_suitability.tif"))
  output_png <- file.path(output_dir, paste0(base_name, "_suitability.png"))
  output_occ_png <- file.path(output_dir, paste0(base_name, "_occurrence.png"))

  log_message(log_fun, "About to run prediction. model_type: ", model_type)
  log_message(log_fun, "env_project_scaled class: ", class(env$env_project_scaled)[1])
  log_message(log_fun, "env_project_scaled nlayers: ", terra::nlyr(env$env_project_scaled))
  log_message(log_fun, "env_project_scaled extent: ", paste(terra::ext(env$env_project_scaled), collapse = ", "))

  if (model_type == "glm") {
    log_message(log_fun, "Running GLM prediction")
    suit <- predict_suitability(fit$model, env$env_project_scaled, output_tif, n_cores, log_fun)
  } else if (model_type == "rangebag") {
    log_message(log_fun, "Running Rangebag prediction")
    suit <- predict_rangebag(fit$model, env$env_project_scaled, output_tif, n_cores, log_fun)
  } else if (model_type == "ensemble") {
    log_message(log_fun, sprintf("Running N-Model Ensemble prediction (%d models)", length(fit$model_types)))
    ens_pred <- predict_ensemble(fit, env$env_project_scaled, output_dir, species, n_cores, log_fun)
    suit <- ens_pred$ensemble_suitability
    output_tif <- ens_pred$paths["ensemble"]
  }

  if (!is.null(boundary)) {
    log_message(log_fun, "Masking prediction to boundary (excluding ocean)")
    suit <- terra::mask(suit, boundary, touches = FALSE)
  }

  progress_step(progress_fun, 0.08, "Summarising outputs")
  suitability_summary_global <- summarise_suitability(suit, threshold)
  suitability_summary_aus <- NULL
  save_suitability_png(suit, occ, projection_extent, species, threshold, output_png, boundary = boundary)
  save_occurrence_png(occ, species, output_occ_png)

  if (model_type == "ensemble" && isTRUE(output_uncertainty) && !is.null(ens_pred$uncertainty)) {
    output_unc_png <- file.path(output_dir, paste0(base_name, "_uncertainty.png"))
    unc_data <- list(
      mean = suit,
      sd = ens_pred$uncertainty$sd,
      cv = ens_pred$uncertainty$cv,
      agreement = ens_pred$uncertainty$agreement
    )
    save_uncertainty_png(unc_data, projection_extent, species, threshold, output_unc_png)
  }

  elapsed <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
  log_message(log_fun, "Completed in ", sprintf("%.1f", elapsed), " seconds")
  metrics <- list(presence_records = nrow(fit$occurrence_used), background_points = nrow(fit$background_xy),
                  auc_mean = fit$cv$auc_mean, auc_sd = fit$cv$auc_sd, cv_folds = fit$cv$k,
                  n_cores = n_cores, elapsed_seconds = elapsed)

  result <- list(
    config = list(species = species, occurrence_file = occurrence_file, worldclim_dir = worldclim_dir,
                  selected_biovars = selected_biovars, training_extent = training_extent, projection_extent = projection_extent,
                  background_n = background_n, min_source_records = min_source_records, merge_small_sources = merge_small_sources,
                  thinning_method = thinning_method, spthin_distance_km = spthin_distance_km,
                  model_type = model_type, n_bags = n_bags, ensemble_weighting = ensemble_weighting, tss_threshold = tss_threshold,
                  include_quadratic = include_quadratic, threshold = threshold,
                  aggregation_factor = aggregation_factor, cv_folds = cv_folds, n_cores = n_cores,
                  use_elevation = isTRUE(use_elevation), elevation_demtype = elevation_demtype,
                  use_soil = isTRUE(use_soil), soil_depth = soil_depth, selected_soil_vars = selected_soil_vars,
                  covariate_cache_dir = covariate_cache_dir, boundary_path = boundary_path,
                  use_microclimate = isTRUE(use_microclimate), modis_year_range = modis_year_range,
                  model_types = model_types, output_uncertainty = isTRUE(output_uncertainty),
                  cv_method = cv_method, n_blocks = n_blocks, block_method = block_method,
                  min_points_per_block = min_points_per_block, enable_tuning = isTRUE(enable_tuning),
                  d = d, force_2d = force_2d),
    occurrence = occ, occurrence_used = fit$occurrence_used, source_counts = sort(table(occ$source), decreasing = TRUE),
    cleaning = cleaned[c("removed_bad_coordinates", "removed_duplicates", "original_rows", "columns")],
    environment = list(names = names(env$env_train_scaled), means = env$means, sds = env$sds,
                       files = env$files, extra_covariates = env$extra_covariates),
    model = fit$model, formula = fit$formula, coefficients = fit$coefficients, cv = fit$cv,
    dimension_info = if (model_type == "glm") {
      NULL
    } else if (model_type == "rangebag") {
      fit$dimension_info
    } else if (model_type == "ensemble") {
      fit$rb_model$dimension_info
    },
    suitability = suit, summary = suitability_summary_global,
    boundary = boundary,
    metrics = metrics, paths = list(tif = output_tif, png = output_png, occ_png = output_occ_png)
  )
  result$report_text <- tempfile(fileext = ".txt")
  write_summary_report(result, result$report_text)
  result
}
