# UI helper values and small rendering functions used by app.R.

biovar_choices <- c(
  "BIO1 Annual mean temperature" = "1", "BIO2 Mean diurnal range" = "2",
  "BIO3 Isothermality" = "3", "BIO4 Temperature seasonality" = "4",
  "BIO5 Max temp warmest month" = "5", "BIO6 Min temp coldest month" = "6",
  "BIO7 Temperature annual range" = "7", "BIO8 Mean temp wettest quarter" = "8",
  "BIO9 Mean temp driest quarter" = "9", "BIO10 Mean temp warmest quarter" = "10",
  "BIO11 Mean temp coldest quarter" = "11", "BIO12 Annual precipitation" = "12",
  "BIO13 Precip wettest month" = "13", "BIO14 Precip driest month" = "14",
  "BIO15 Precipitation seasonality" = "15", "BIO16 Precip wettest quarter" = "16",
  "BIO17 Precip driest quarter" = "17", "BIO18 Precip warmest quarter" = "18",
  "BIO19 Precip coldest quarter" = "19"
)

extent_from_inputs <- function(input) {
  switch(input$extent_preset,
         world = c(-180, 180, -90, 90),
         aus_full = c(112, 155, -45, -10),
         aus_north = c(112, 155, -30, -10),
         aus_east = c(140, 155, -38, -10),
         custom = c(input$xmin, input$xmax, input$ymin, input$ymax),
         c(-180, 180, -90, 90))
}

fmt_num <- function(x, digits = 0) {
  if (length(x) == 0 || is.null(x) || !is.finite(x)) return("-")
  format(round(x, digits), big.mark = ",", nsmall = digits)
}

metric_card <- function(label, value, note = NULL) {
  div(class = "metric-card", div(class = "metric-label", label), div(class = "metric-value", value), if (!is.null(note)) div(class = "metric-note", note))
}

placeholder_plot <- function(message) {
  plot.new()
  text(0.5, 0.55, message, cex = 1.1, col = "grey35")
  text(0.5, 0.46, "Configure options on the left, then click Run SDM.", cex = 0.9, col = "grey55")
}

opentopo_key_is_configured <- function() nzchar(Sys.getenv("OPENTOPOGRAPHY_API_KEY", unset = ""))
