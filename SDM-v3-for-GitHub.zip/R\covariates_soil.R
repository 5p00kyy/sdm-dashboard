# SoilGrids250m covariate loading for SDMs.

soilgrids_soil_choices <- c(
  "Soil pH (H2O)" = "phh2o",
  "Soil Organic Carbon (g/kg)" = "soc",
  "Cation Exchange Capacity (cmol/kg)" = "cec",
  "Bulk Density (kg/dm3)" = "bdod",
  "Total Nitrogen (g/kg)" = "nitrogen",
  "Clay Content (%)" = "clay",
  "Sand Content (%)" = "sand",
  "Silt Content (%)" = "silt"
)

soilgrids_default_vars <- c("phh2o", "soc", "cec", "bdod")

load_soil_covariate <- function(soil_path = NULL,
                                selected_soil_vars = soilgrids_default_vars,
                                depth_cm = 30,
                                allow_download = TRUE,
                                log_fun = NULL) {
  selected_soil_vars <- unique(as.character(selected_soil_vars))
  selected_soil_vars <- selected_soil_vars[nzchar(selected_soil_vars)]

  if (length(selected_soil_vars) == 0) {
    log_message(log_fun, "Soil covariates selected, but no soil variables were chosen.")
    return(NULL)
  }

  cache_dir <- "covariates/soilgrids"
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)

  source("R/download_soilgrids.R")

  log_message(log_fun, "Loading/retrieving SoilGrids soil covariates for: ", paste(selected_soil_vars, collapse = ", "))

  result <- download_soilgrids_covariates(
    selected_properties = selected_soil_vars,
    depth_cm = depth_cm,
    cache_dir = cache_dir,
    log_fun = log_fun
  )

  if (is.null(result) || length(result) == 0) {
    log_message(log_fun, "Failed to retrieve SoilGrids soil covariates")
    return(NULL)
  }

  loaded <- load_soilgrids_covariates(
    cache_dir = cache_dir,
    selected_properties = selected_soil_vars,
    depth_cm = depth_cm,
    log_fun = log_fun
  )

  if (is.null(loaded)) {
    log_message(log_fun, "Failed to load cached SoilGrids files")
    return(NULL)
  }

  log_message(log_fun, "Loaded ", length(selected_soil_vars), " SoilGrids soil layer(s)")

  loaded
}