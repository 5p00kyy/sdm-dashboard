# User-friendly web interface for the SDM project
# Run with: Rscript app.R

cmd_args <- commandArgs(FALSE)
file_arg <- grep("^--file=", cmd_args, value = TRUE)
if (length(file_arg) > 0) {
  app_path <- normalizePath(sub("^--file=", "", file_arg[1]), winslash = "/", mustWork = TRUE)
  setwd(dirname(app_path))
} else {
  app_ofiles <- vapply(sys.frames(), function(frame) {
    if (!is.null(frame$ofile)) frame$ofile else NA_character_
  }, character(1))
  app_ofiles <- app_ofiles[!is.na(app_ofiles) & basename(app_ofiles) == "app.R"]
  if (length(app_ofiles) > 0) {
    app_path <- normalizePath(app_ofiles[length(app_ofiles)], winslash = "/", mustWork = TRUE)
    setwd(dirname(app_path))
  }
}

# Load the modelling engine. R/optimized_sdm.R is now a compatibility loader
# for the refactored modules; the root file remains as an older launch fallback.
engine_candidates <- unique(c(
  file.path("R", "optimized_sdm.R"),
  "optimized_sdm.R",
  file.path(dirname(normalizePath("app.R", winslash = "/", mustWork = FALSE)), "R", "optimized_sdm.R"),
  file.path(dirname(normalizePath("app.R", winslash = "/", mustWork = FALSE)), "optimized_sdm.R")
))
engine_file <- engine_candidates[file.exists(engine_candidates)][1]
if (is.na(engine_file)) {
  stop(
    "Could not find the modelling engine file optimized_sdm.R.\n",
    "Expected either R/optimized_sdm.R or optimized_sdm.R in the same folder as app.R.\n",
    "Your zip/extraction is incomplete. Re-extract the full SDM folder or copy the missing R folder."
  )
}
source(engine_file)
source("R/packages.R")
source("R/load.R")
default_cores <- max(1L, detect_available_cores(TRUE) - 1L)
ensure_sdm_packages(c("shiny", "bslib", "terra"), n_cores = default_cores)

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
})

options(shiny.maxRequestSize = 300 * 1024^2)

ui <- fluidPage(
  theme = bslib::bs_theme(version = 5, bootswatch = "darkly", primary = "#0B6E69"),
  tags$head(tags$style(HTML("\n    .hero { background: linear-gradient(135deg,#0B6E69 0%,#174A7C 100%); color:white; border-radius:18px; padding:28px 32px; margin:18px 0 20px; box-shadow:0 12px 28px rgba(0,0,0,.3);}\n    .hero h1 { font-weight:800; margin:0 0 8px; } .hero p { margin:0; opacity:.92; font-size:1.05rem; }\n    .control-panel,.content-card,.metric-card { background:#272c30; border-radius:16px; box-shadow:0 10px 24px rgba(0,0,0,.3); }\n    .control-panel { padding:18px; } .content-card { padding:18px; margin-bottom:16px; }\n    .metric-grid { display:grid; grid-template-columns:repeat(4,minmax(150px,1fr)); gap:14px; margin-bottom:16px; }\n    .metric-card { border-left:5px solid #0B6E69; padding:16px; } .metric-label { color:#8b9daa; font-size:.83rem; text-transform:uppercase; letter-spacing:.05em; }\n    .metric-value { color:#e8eaed; font-size:1.75rem; font-weight:800; line-height:1.2; }\n    .metric-note { color:#8b9daa; font-size:.85rem; margin-top:4px; }\n    .status-ok,.status-warn,.status-error { border-radius:12px; padding:12px 14px; margin-bottom:16px; }\n    .status-ok { background:#1a3d35; border:1px solid #2d6a5c; color:#7dd3c0; } .status-warn { background:#3d2e10; border:1px solid #665020; color:#f5d98e; } .status-error { background:#3d1816; border:1px solid #6d2624; color:#f5a49a; }\n    pre { background:#0d0f12; color:#d6e4ff; border-radius:12px; padding:14px; } [data-bs-theme=\"dark\"] pre { background:#0d0f12; }\n    .small-muted { color:#6c7a89; font-size:.9rem; }\n    @media(max-width:1100px){.metric-grid{grid-template-columns:repeat(2,minmax(150px,1fr));}} @media(max-width:700px){.metric-grid{grid-template-columns:1fr;}}\n  "))),

  div(class = "hero", h1("Species Distribution Model Web Interface"), p("Fast habitat suitability mapping for presence-only occurrence datasets.")),

  sidebarLayout(
    sidebarPanel(width = 3, class = "control-panel",
      h4("1. Input data"),
      textInput("species", "Species name", value = "Piper aduncum"),
      fileInput("occ_file", "Upload occurrence CSV/TSV", accept = c(".csv", ".tsv", ".txt")),
      div(class = "small-muted", "If presence_data.csv exists in the project folder, it is used when no file is uploaded."), br(),
      textInput("worldclim_dir", "WorldClim folder", value = "Worldclim"),
      checkboxInput("download_worldclim", "Download missing WorldClim/elevation layers", value = TRUE),
      selectInput("worldclim_res", "WorldClim resolution", choices = c("10 arc-min" = "10", "5 arc-min" = "5", "2.5 arc-min" = "2.5"), selected = "10"),

      hr(), h4("2. Environmental covariates"),
      checkboxGroupInput("biovars", "Climate variables", choices = biovar_choices, selected = c("1", "4", "6", "12", "15", "18")),
      checkboxInput("use_elevation", "Add elevation from OpenTopography", value = FALSE),
      conditionalPanel("input.use_elevation == true",
        selectInput("elevation_demtype", "Elevation DEM", choices = opentopo_dem_choices, selected = "COP90"),
        passwordInput("opentopo_api_key", "OpenTopography API key (optional)", value = ""),
        div(class = "small-muted", "Leave blank to use OPENTOPOGRAPHY_API_KEY from your environment. Keys are not saved in outputs.")
      ),
      checkboxInput("use_soil", "Add SoilGrids soil covariates", value = FALSE),
      conditionalPanel("input.use_soil == true",
        selectInput("soil_depth", "Soil depth", choices = c("0-30 cm" = "30", "0-60 cm" = "60"), selected = "30"),
        checkboxGroupInput("soil_vars", "Soil properties", choices = soilgrids_soil_choices, selected = soilgrids_default_vars),
        div(class = "small-muted", "Data source: SoilGrids250m (ISRIC). Downloads tiles on demand.")
      ),

      hr(), h4("3. Model settings"),
      numericInput("background_n", "Background points", value = 10000, min = 500, max = 100000, step = 500),
      numericInput("min_source_records", "Merge sources with fewer than", value = 15, min = 1, max = 100, step = 1),
      radioButtons("thinning_method", "Spatial thinning", choices = c("None" = "none", "Grid-based (raster cell)" = "cell", "Distance-based (spThin)" = "distance"), selected = "cell"),
      conditionalPanel("input.thinning_method == 'distance'",
        numericInput("spthin_distance", "Minimum distance (km)", value = 10, min = 1, max = 500, step = 5),
        div(class = "small-muted", "Recommended: 10-50km to reduce spatial autocorrelation")
      ),
      selectInput("model_type", "Model", choices = c("GLM (logistic regression)" = "glm", "Rangebagging" = "rangebag", "Ensemble (GLM + Rangebag)" = "ensemble"), selected = "glm"),
      conditionalPanel("input.model_type == 'rangebag' || input.model_type == 'ensemble'",
        numericInput("n_bags", "Number of bags", value = 100, min = 10, max = 500, step = 10),
        div(class = "small-muted", "More bags = more stable predictions but slower"),
        selectInput("rangebag_dim", "Rangebag dimensions", choices = c("1D (ranges) - default" = "1", "2D (convex hull)" = "2"), selected = "1"),
        checkboxInput("force_2d", "Force 2D (no automatic fallback to 1D)", value = FALSE),
        div(class = "small-muted", "2D uses convex hulls; may fail with small/irregular data")
      ),
      conditionalPanel("input.model_type == 'ensemble'",
        selectInput("ensemble_weighting", "Ensemble weighting", choices = c("TSS-weighted (recommended)" = "tss", "AUC-weighted" = "auc", "Equal weights" = "equal"), selected = "tss"),
        numericInput("tss_threshold", "Minimum TSS to include", value = 0.6, min = 0, max = 1, step = 0.05),
        div(class = "small-muted", "Models with TSS below threshold are excluded from ensemble")
      ),
      checkboxInput("enable_climate_change", "Project future climate", value = FALSE),
      conditionalPanel("input.enable_climate_change == true",
        selectInput("cmip6_ssp", "SSP scenario", choices = c("SSP2-4.5 (moderate)" = "245", "SSP5-8.5 (severe)" = "585"), selected = "585"),
        selectInput("cmip6_time", "Time period", choices = c("2041-2060 (mid-century)" = "2041-2060", "2061-2080 (end-century)" = "2061-2080"), selected = "2061-2080"),
        checkboxGroupInput("cmip6_models", "Climate models (GCM)", choices = c("ACCESS-CM2" = "ACCESS-CM2", "MPI-ESM1-2-HR" = "MPI-ESM1-2-HR", "UKESM1-0-LL" = "UKESM1-0-LL"), selected = "ACCESS-CM2"),
        div(class = "small-muted", "Select one or more. Multiple models will be averaged.")
      ),
      checkboxInput("quadratic", "Include quadratic climate responses", value = TRUE),
      selectInput("cv_folds", "Cross-validation", choices = c("3-fold" = "3", "5-fold" = "5", "10-fold" = "10"), selected = "5"),
      numericInput("n_cores", "CPU cores for compile/predict/CV", value = default_cores, min = 1, max = detect_available_cores(TRUE), step = 1),
      div(class = "small-muted", "Also sets MAKEFLAGS=-jN for source package compilation."),
      numericInput("aggregation_factor", "Raster aggregation for speed (1 = native)", value = 1, min = 1, max = 8, step = 1),

      hr(), h4("4. Projection"),
      selectInput("extent_preset", "Projection extent", choices = c("World (full)" = "world", "Australia - full" = "aus_full", "Northern Australia" = "aus_north", "Eastern Australia" = "aus_east", "Custom" = "custom"), selected = "world"),
      conditionalPanel("input.extent_preset == 'custom'",
        fluidRow(column(6, numericInput("xmin", "xmin", 112)), column(6, numericInput("xmax", "xmax", 155))),
        fluidRow(column(6, numericInput("ymin", "ymin", -45)), column(6, numericInput("ymax", "ymax", -10)))
      ),
      hr(),
      radioButtons("boundary_type", "Boundary file",
        choices = c("None (rectangular extent)" = "none",
                    "Australia (default)" = "australia",
                    "Upload custom boundary" = "custom"),
        selected = "australia"
      ),
      conditionalPanel("input.boundary_type == 'custom'",
        fileInput("boundary_file", "Upload KML/Shapefile", accept = c(".kml", ".kmz", ".shp", ".shx", ".gpkg")),
        div(class = "small-muted", "Upload a KML, KMZ, Shapefile, or GeoPackage boundary file.")
      ),
      checkboxInput("show_boundary_line", "Show boundary line on map", value = FALSE),
      sliderInput("threshold", "High-risk threshold", min = 0.05, max = 0.95, value = 0.50, step = 0.05),
      hr(),
      actionButton("run_model", "Run SDM", class = "btn-primary btn-lg", width = "100%")
    ),

    mainPanel(width = 9,
      uiOutput("status_banner"), uiOutput("metric_cards"),
      tabsetPanel(id = "tabs",
        tabPanel("Dashboard", br(), fluidRow(column(8, div(class = "content-card", plotOutput("suitability_plot", height = "620px"))), column(4, div(class = "content-card", h4("Projection summary"), verbatimTextOutput("summary_text"))))),
        tabPanel("Occurrences", br(), fluidRow(column(7, div(class = "content-card", plotOutput("occurrence_plot", height = "540px"))), column(5, div(class = "content-card", h4("Top data sources"), tableOutput("source_table"))))),
        tabPanel("Model diagnostics", br(), fluidRow(column(7, div(class = "content-card", h4("Coefficient summary"), tableOutput("coef_table"))), column(5, div(class = "content-card", h4("Run log"), verbatimTextOutput("run_log"))))),
        tabPanel("Configuration", br(), div(class = "content-card", uiOutput("config_table"))),
        tabPanel("Climate Change", br(),
          uiOutput("climate_change_tabs")
        ),
        tabPanel("Downloads", br(), div(class = "content-card", h4("Export results"), p("Downloads are enabled after a successful run."), downloadButton("download_tif", "Download GeoTIFF"), downloadButton("download_png", "Download PNG map"), downloadButton("download_occ_png", "Download occurrence map PNG"), downloadButton("download_occ", "Download cleaned occurrences"), downloadButton("download_report", "Download text report"), uiOutput("future_downloads")))
      )
    )
  )
)

server <- function(input, output, session) {
  rv <- reactiveValues(result = NULL, log = "Ready.\n", error = NULL, running = FALSE)
  append_log <- function(message) rv$log <- paste0(rv$log, format(Sys.time(), "%H:%M:%S"), "  ", message, "\n")

  output$status_banner <- renderUI({
    if (isTRUE(rv$running)) div(class = "status-warn", strong("Running model... "), "Large rasters/downloads can take several minutes.")
    else if (!is.null(rv$error)) div(class = "status-error", strong("Run failed: "), rv$error)
    else if (!is.null(rv$result)) div(class = "status-ok", strong("Run complete. "), "Review maps, diagnostics, and downloads below.")
    else div(class = "status-warn", strong("Ready. "), "Upload data or restore presence_data.csv, then click Run SDM.")
  })

  observeEvent(input$run_model, {
    rv$error <- NULL; rv$running <- TRUE; rv$log <- ""
    occurrence_file <- if (!is.null(input$occ_file)) input$occ_file$datapath else if (file.exists("presence_data.csv")) "presence_data.csv" else NULL
    if (is.null(occurrence_file)) {
      rv$error <- "No occurrence file found. Upload a CSV/TSV or restore presence_data.csv."
      append_log(rv$error); rv$running <- FALSE; return(invisible(NULL))
    }
    if (length(input$biovars) < 2) {
      rv$error <- "Select at least two BIOCLIM variables."
      append_log(rv$error); rv$running <- FALSE; return(invisible(NULL))
    }
    if (isTRUE(input$use_soil) && length(input$soil_vars) == 0) {
      rv$error <- "Select at least one HWSD soil property, or turn soil covariates off."
      append_log(rv$error); rv$running <- FALSE; return(invisible(NULL))
    }
    projection_extent <- extent_from_inputs(input)

    boundary_path <- NULL
    if (!is.null(input$boundary_type)) {
      boundary_path <- switch(input$boundary_type,
        "none" = NULL,
        "australia" = file.path("Australia Boundary", "AUS_2021_AUST_GDA2020.shp"),
        "custom" = if (!is.null(input$boundary_file)) input$boundary_file$datapath else NULL
      )
    }

    withProgress(message = "Running SDM", value = 0, {
      result <- tryCatch(
        withCallingHandlers(
          run_fast_sdm(
            species = input$species, occurrence_file = occurrence_file, worldclim_dir = input$worldclim_dir,
            selected_biovars = as.integer(input$biovars), projection_extent = projection_extent,
            background_n = input$background_n, min_source_records = input$min_source_records,
            merge_small_sources = TRUE, thinning_method = input$thinning_method, spthin_distance_km = input$spthin_distance,
            model_type = input$model_type, n_bags = input$n_bags,
            d = as.integer(input$rangebag_dim), force_2d = isTRUE(input$force_2d),
            ensemble_weighting = input$ensemble_weighting, tss_threshold = input$tss_threshold,
            include_quadratic = isTRUE(input$quadratic),
            threshold = input$threshold, aggregation_factor = input$aggregation_factor, cv_folds = as.integer(input$cv_folds),
            n_cores = input$n_cores, allow_download = isTRUE(input$download_worldclim), worldclim_res = as.numeric(input$worldclim_res),
            use_elevation = isTRUE(input$use_elevation), elevation_demtype = input$elevation_demtype,
            opentopo_api_key = input$opentopo_api_key,
            use_soil = isTRUE(input$use_soil), soil_depth = as.integer(input$soil_depth), selected_soil_vars = input$soil_vars,
            covariate_cache_dir = "covariates",
            boundary_path = boundary_path,
            output_dir = "outputs", seed = 42, log_fun = append_log,
            progress_fun = function(amount, detail) incProgress(amount, detail = detail)
          ),
          warning = function(w) { append_log(paste("Warning:", conditionMessage(w))); invokeRestart("muffleWarning") }
        ),
        error = function(e) { rv$error <- conditionMessage(e); append_log(paste("ERROR:", conditionMessage(e))); NULL }
      )
      if (!is.null(result)) rv$result <- result
    })
    rv$running <- FALSE
  })

  observeEvent(input$run_future_projection, {
    r <- rv$result
    if (is.null(r)) return()
    cmip6_models <- input$cmip6_models
    if (is.null(cmip6_models) || length(cmip6_models) == 0) {
      cmip6_models <- "ACCESS-CM2"
      append_log("No GCM selected, defaulting to ACCESS-CM2")
    }
    append_log("Starting future climate projection...")
    withProgress(message = "Future Climate Projection", value = 0, {
      tryCatch({
        incProgress(0.1, detail = "Loading climate data")
        future_result <- predict_future_suitability(
          r, "Worldclim/future", as.integer(input$biovars), r$config$projection_extent,
          r$config$aggregation_factor, cmip6_models, input$cmip6_ssp, input$cmip6_time,
          input$n_cores, append_log
        )
        r$future <- future_result
        rv$result <- r
        append_log("Future climate projection completed.")
      }, error = function(e) {
        append_log(paste("Future projection failed:", conditionMessage(e)))
      })
    })
  })

  output$metric_cards <- renderUI({
    r <- rv$result
    if (is.null(r)) return(div(class = "metric-grid", metric_card("Records", "-", "waiting for run"), metric_card("Covariates", "-", "waiting for run"), metric_card("AUC", "-", "cross-validation"), metric_card("High-risk area", "-", "km2 above threshold")))
    boundary_note <- if (!is.null(r$boundary)) " (terrestrial)" else ""
    div(class = "metric-grid",
        metric_card("Records used", fmt_num(r$metrics$presence_records), "after cleaning/thinning"),
        metric_card("Covariates", fmt_num(length(r$environment$names)), "climate/elevation/soil"),
        metric_card("CV AUC", fmt_num(r$metrics$auc_mean, 3), paste0(r$metrics$cv_folds, " folds; ", r$metrics$n_cores, " cores")),
        metric_card("High-risk area", fmt_num(r$summary$high_risk_area_km2), paste0("km2", boundary_note))
    )
  })

  output$suitability_plot <- renderPlot({ if (is.null(rv$result)) return(placeholder_plot("No suitability map yet.")); r <- rv$result; plot_suitability_map(r$suitability, r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary) })
  output$occurrence_plot <- renderPlot({ if (is.null(rv$result)) return(placeholder_plot("No occurrence map yet.")); plot_occurrence_map(rv$result$occurrence, rv$result$config$species) })
  output$summary_text <- renderText({
    r <- rv$result; if (is.null(r)) return("No model has been run yet.")
    extent_label <- if (!is.null(r$boundary)) " (terrestrial/boundary)" else " (full extent)"
    paste("--- Projection Summary", extent_label, "---\n",
          "Mean suitability:", fmt_num(r$summary$mean, 3), "\n",
          "Median suitability:", fmt_num(r$summary$median, 3), "\n",
          "Maximum suitability:", fmt_num(r$summary$max, 3), "\n",
          "Cells above threshold:", fmt_num(r$summary$cells_above_threshold), paste0(" (", fmt_num(r$summary$percent_above_threshold, 1), "%)"), "\n",
          "High-risk area (km2):", fmt_num(r$summary$high_risk_area_km2), "\n\n",
          "Covariates:", paste(r$environment$names, collapse = ", "), "\n",
          "CPU cores used:", r$metrics$n_cores, "\n",
          "Elapsed time (sec):", fmt_num(r$metrics$elapsed_seconds, 1), "\n",
          "Output TIFF:", r$paths$tif, sep = "")
  })
  output$source_table <- renderTable({ r <- rv$result; if (is.null(r)) return(data.frame(Message = "Run the model to view source counts.")); head(data.frame(Source = names(r$source_counts), Records = as.integer(r$source_counts), row.names = NULL), 25) }, striped = TRUE, hover = TRUE, spacing = "s")
  output$coef_table <- renderTable({ r <- rv$result; if (is.null(r)) return(data.frame(Message = "Run the model to view coefficients.")); co <- r$coefficients; numeric_cols <- vapply(co, is.numeric, logical(1)); co[numeric_cols] <- lapply(co[numeric_cols], function(x) signif(x, 4)); co }, striped = TRUE, hover = TRUE, spacing = "s")
  output$run_log <- renderText(rv$log)

  output$config_table <- renderUI({
    r <- rv$result
    if (is.null(r)) return(div(class = "content-card", "Run the model first to view configuration."))

    c <- r$config

    config_rows <- data.frame(
      Parameter = c(
        "Species",
        "Occurrence file",
        "WorldClim directory",
        "BIO variables",
        "Thinning method",
        "Thinning distance (km)",
        "Background points",
        "Min source records",
        "Include quadratic terms",
        "Threshold",
        "Aggregation factor",
        "Cross-validation folds",
        "CPU cores",
        "Projection extent",
        "Boundary file",
        "Use elevation",
        "Use soil"
      ),
      Value = c(
        c$species,
        c$occurrence_file,
        c$worldclim_dir,
        paste(c$selected_biovars, collapse = ", "),
        switch(c$thinning_method, "none" = "None", "cell" = "Grid-based (raster cell)", "distance" = "Distance-based (spThin)"),
        if (c$thinning_method == "distance") as.character(c$spthin_distance_km) else "N/A",
        as.character(c$background_n),
        as.character(c$min_source_records),
        if (isTRUE(c$include_quadratic)) "Yes" else "No",
        as.character(c$threshold),
        as.character(c$aggregation_factor),
        if (c$cv_folds > 0) as.character(c$cv_folds) else "Off",
        as.character(c$n_cores),
        paste(c$projection_extent, collapse = ", "),
        if (is.null(c$boundary_path) || c$boundary_path == "") "None" else basename(c$boundary_path),
        if (isTRUE(c$use_elevation)) paste("Yes (", c$elevation_demtype, ")", sep = "") else "No",
        if (isTRUE(c$use_soil)) "Yes" else "No"
      ),
      stringsAsFactors = FALSE
    )

    if (c$model_type %in% c("rangebag", "ensemble")) {
      rb_rows <- data.frame(
        Parameter = c("--- Rangebag Settings ---", "Requested dimensions", "Force 2D"),
        Value = c("", paste0(c$d, "D"), if (isTRUE(c$force_2d)) "Yes" else "No"),
        stringsAsFactors = FALSE
      )
      config_rows <- rbind(config_rows, rb_rows)
    }

    if (!is.null(r$dimension_info)) {
      dim_info <- r$dimension_info
      dim_status <- if (dim_info$global_fallback || dim_info$fallback_count > 0) {
        paste0("Yes (", dim_info$fallback_count, " fallbacks)")
      } else {
        "No"
      }
      dim_rows <- data.frame(
        Parameter = c("--- Rangebag Details ---", "Requested dimension", "Actual dimension used", "Fallbacks triggered"),
        Value = c("", dim_info$requested, dim_info$used, dim_status),
        stringsAsFactors = FALSE
      )
      config_rows <- rbind(config_rows, dim_rows)
    }

    if (!is.null(r$future)) {
      f <- r$future
      future_rows <- data.frame(
        Parameter = c("--- Future Climate ---", "GCM models", "SSP scenario", "Time period"),
        Value = c("", paste(f$scenario$models, collapse = ", "), paste0("SSP", f$scenario$ssp), f$scenario$time),
        stringsAsFactors = FALSE
      )
      config_rows <- rbind(config_rows, future_rows)
    }

    tagList(
      h4("Run Configuration"),
      p(class = "small-muted", "Parameter settings used in this model run"),
      renderTable(config_rows, striped = TRUE, hover = TRUE, spacing = "s", rownames = FALSE)
    )
  })

  output$climate_change_tabs <- renderUI({
    r <- rv$result
    if (is.null(r)) {
      return(div(class = "content-card", "Run the SDM model first to enable future climate projections."))
    }
    if (is.null(r$future)) {
      selected_models <- paste(input$cmip6_models, collapse = ", ")
      if (is.null(selected_models) || selected_models == "") selected_models <- "ACCESS-CM2"
      return(div(class = "content-card",
        h4("Future Climate Projection"),
        p("Click below to project species distribution under future climate conditions."),
        p("This will download CMIP6 climate data if not already present (~10MB per scenario)."),
        actionButton("run_future_projection", "Run Future Climate Projection", class = "btn-primary"),
        hr(),
        p(class = "small-muted", "Settings: SSP ", input$cmip6_ssp, ", ", input$cmip6_time, ", GCMs: ", selected_models)
      ))
    }
    f <- r$future
    scenario_text <- paste0(f$scenario$model, ", SSP", f$scenario$ssp, ", ", f$scenario$time)

    accordion_scripts <- NULL
    if (!is.null(f$individual) && length(f$individual$suitabilities) > 1) {
      accordion_scripts <- bslib::accordion(
        open = FALSE,
        bslib::accordion_panel("Individual GCM Maps",
          fluidRow(
            column(4, div(class = "content-card", h5("ACCESS-CM2"), plotOutput("gcm_access_plot", height = "200px"))),
            column(4, div(class = "content-card", h5("MPI-ESM1-2-HR"), plotOutput("gcm_mpi_plot", height = "200px"))),
            column(4, div(class = "content-card", h5("UKESM1-0-LL"), plotOutput("gcm_ukesm_plot", height = "200px")))
          )
        )
      )
    }

    tagList(
      fluidRow(
        column(6, div(class = "content-card", h4("Current climate (1970-2000)"), plotOutput("current_climate_plot", height = "280px"))),
        column(6, div(class = "content-card", h4(paste0("Future climate (", scenario_text, ")")), plotOutput("future_climate_plot", height = "280px"))),
        column(12, div(class = "content-card", h4("Habitat change (future - current)"), plotOutput("delta_climate_plot", height = "300px"),
          h5(paste0("Gain: ", fmt_num(f$delta_summary$cells_above_threshold), " cells above 0 (positive change)"))))
      ),
      if (!is.null(accordion_scripts)) accordion_scripts
    )
  })

  output$current_climate_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future)) return(placeholder_plot("No future projection"))
    plot_suitability_map(r$suitability, r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary)
  })

  output$future_climate_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future)) return(placeholder_plot("No future projection"))
    plot_suitability_map(r$future$suitability, r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary)
  })

  output$delta_climate_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future)) return(placeholder_plot("No future projection"))
    plot_delta_map(r$future$delta, r$config$projection_extent, r$config$species)
  })

  output$gcm_access_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future) || is.null(r$future$individual)) return(placeholder_plot("No data"))
    if (!"ACCESS-CM2" %in% names(r$future$individual$suitabilities)) return(placeholder_plot("Not selected"))
    plot_suitability_map(r$future$individual$suitabilities[["ACCESS-CM2"]], r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary)
  })

  output$gcm_mpi_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future) || is.null(r$future$individual)) return(placeholder_plot("No data"))
    if (!"MPI-ESM1-2-HR" %in% names(r$future$individual$suitabilities)) return(placeholder_plot("Not selected"))
    plot_suitability_map(r$future$individual$suitabilities[["MPI-ESM1-2-HR"]], r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary)
  })

  output$gcm_ukesm_plot <- renderPlot({
    r <- rv$result
    if (is.null(r) || is.null(r$future) || is.null(r$future$individual)) return(placeholder_plot("No data"))
    if (!"UKESM1-0-LL" %in% names(r$future$individual$suitabilities)) return(placeholder_plot("Not selected"))
    plot_suitability_map(r$future$individual$suitabilities[["UKESM1-0-LL"]], r$occurrence, r$config$projection_extent, r$config$species, r$config$threshold, TRUE, show_boundary_line = isTRUE(input$show_boundary_line), boundary = r$boundary)
  })

  output$future_downloads <- renderUI({
    r <- rv$result
    if (is.null(r) || is.null(r$future)) return(NULL)
    tagList(
      hr(),
      h5("Future Climate Downloads"),
      downloadButton("download_future_tif", "Download future suitability GeoTIFF"),
      downloadButton("download_delta_tif", "Download change (delta) GeoTIFF")
    )
  })

  output$download_future_tif <- downloadHandler(
    filename = function() if (is.null(rv$result$future)) "future_suitability.tif" else basename(rv$result$future$paths$tif),
    content = function(file) { req(rv$result$future, file.exists(rv$result$future$paths$tif)); file.copy(rv$result$future$paths$tif, file, overwrite = TRUE) }
  )

  output$download_delta_tif <- downloadHandler(
    filename = function() if (is.null(rv$result$future)) "delta.tif" else basename(rv$result$future$paths$delta),
    content = function(file) { req(rv$result$future, file.exists(rv$result$future$paths$delta)); file.copy(rv$result$future$paths$delta, file, overwrite = TRUE) }
  )

  output$download_tif <- downloadHandler(filename = function() basename(rv$result$paths$tif), content = function(file) { req(rv$result, file.exists(rv$result$paths$tif)); file.copy(rv$result$paths$tif, file, overwrite = TRUE) })
  output$download_png <- downloadHandler(filename = function() basename(rv$result$paths$png), content = function(file) { req(rv$result, file.exists(rv$result$paths$png)); file.copy(rv$result$paths$png, file, overwrite = TRUE) })
  output$download_occ_png <- downloadHandler(filename = function() basename(rv$result$paths$occ_png), content = function(file) { req(rv$result, file.exists(rv$result$paths$occ_png)); file.copy(rv$result$paths$occ_png, file, overwrite = TRUE) })
  output$download_occ <- downloadHandler(filename = function() paste0(safe_slug(input$species), "_cleaned_occurrences.csv"), content = function(file) { req(rv$result); utils::write.csv(rv$result$occurrence, file, row.names = FALSE) })
  output$download_report <- downloadHandler(filename = function() paste0(safe_slug(input$species), "_sdm_report.txt"), content = function(file) { req(rv$result); write_summary_report(rv$result, file) })
}

if (sys.nframe() == 0) {
  port <- as.integer(Sys.getenv("PORT", "3838"))
  shiny::runApp(shiny::shinyApp(ui, server), host = "0.0.0.0", port = port)
}
