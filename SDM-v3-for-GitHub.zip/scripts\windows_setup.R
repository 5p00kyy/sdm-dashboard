#!/usr/bin/env Rscript
# One-time/first-run preparation used by run_app_windows.bat.

if (!file.exists("app.R") || !dir.exists("R")) {
  stop("Run this script from the extracted SDM project folder.", call. = FALSE)
}

cat("Loading R modules...\n")

tryCatch({
  source(file.path("R", "optimized_sdm.R"))
  cat("  - Loaded R/optimized_sdm.R\n")
}, error = function(e) {
  stop("ERROR: Failed to load R/optimized_sdm.R\n  ", conditionMessage(e), call. = FALSE)
})

tryCatch({
  source("R/load.R")
  cat("  - Loaded R/load.R (", length(list.files("R", pattern = "\\.R$")), " modules)\n")
}, error = function(e) {
  stop("ERROR: Failed to load R/load.R\n  ", conditionMessage(e), call. = FALSE)
})

n_cores <- max(1L, detect_available_cores(TRUE) - 1L)
cat("Preparing SDM app with ", n_cores, " worker(s).\n", sep = "")

ensure_sdm_packages(sdm_app_packages, n_cores = n_cores)

dir.create("outputs", showWarnings = FALSE)
dir.create("covariates", showWarnings = FALSE)
dir.create(file.path("covariates", "opentopo"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("covariates", "hwsd_v2"), recursive = TRUE, showWarnings = FALSE)

default_biovars <- c(1, 4, 6, 12, 15, 18)
missing_worldclim <- any(is.na(find_worldclim_files("Worldclim", default_biovars)))
if (missing_worldclim) {
  cat("Default WorldClim layers are missing. Attempting download now.\n")
  wc_ok <- tryCatch({
    ensure_sdm_packages("geodata", n_cores = n_cores)
    download_worldclim_layers("Worldclim", default_biovars, res = 10, n_cores = n_cores)
    TRUE
  }, error = function(e) {
    message("WorldClim pre-download skipped: ", conditionMessage(e))
    FALSE
  })
  if (!wc_ok) {
    cat("The app will still launch. Keep download enabled in the app and check your internet connection before running a model.\n")
  }
} else {
  cat("Default WorldClim layers are already available.\n")
}

if (!nzchar(Sys.getenv("OPENTOPOGRAPHY_API_KEY", unset = ""))) {
  cat("OpenTopography API key is not set. Elevation can still be used by entering a key in the app.\n")
}

cat("Windows setup complete. Launching the app next.\n")
