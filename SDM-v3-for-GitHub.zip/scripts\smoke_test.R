#!/usr/bin/env Rscript
# Lightweight source/API smoke test. Does not download data or fit a model.

source(file.path("R", "optimized_sdm.R"))
source("R/load.R")

required_functions <- c(
  "run_fast_sdm", "load_environment", "download_worldclim_layers",
  "opentopo_globaldem_url", "load_soil_covariate", "plot_suitability_map",
  "write_summary_report", "detect_available_cores"
)
missing <- required_functions[!vapply(required_functions, exists, logical(1), mode = "function")]
if (length(missing) > 0) {
  stop("Missing expected functions: ", paste(missing, collapse = ", "), call. = FALSE)
}

invisible(validate_extent(c(112, 155, -45, -10), "smoke extent"))
formula <- make_sdm_formula(c("bio1", "bio12", "elevation_m"), include_quadratic = TRUE)
if (!inherits(formula, "formula")) stop("Formula helper failed.", call. = FALSE)

cat("SDM smoke test passed. Modules source correctly.\n")
