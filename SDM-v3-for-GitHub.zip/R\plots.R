# Plotting helpers used by the Shiny app and output writer.

plot_suitability_map <- function(suitability, occ = NULL, projection_extent = NULL, species = "Species", threshold = 0.5, add_points = TRUE, show_boundary_line = FALSE, boundary = NULL) {
  cols <- hcl.colors(100, "Inferno", rev = FALSE)
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par), add = TRUE)
  graphics::par(mar = c(4, 4, 3, 5), bg = "white")
  terra::plot(suitability, col = cols, range = c(0, 1), main = paste0(species, " suitability"),
              axes = TRUE, xlab = "Longitude", ylab = "Latitude")
  if (!is.null(occ) && add_points) {
    pts <- occ
    if (!is.null(projection_extent)) {
      pts <- pts[pts$longitude >= projection_extent[1] & pts$longitude <= projection_extent[2] &
                   pts$latitude >= projection_extent[3] & pts$latitude <= projection_extent[4], , drop = FALSE]
    }
    if (nrow(pts) > 0) {
      graphics::points(pts$longitude, pts$latitude, pch = 21, cex = 0.6,
                       bg = grDevices::adjustcolor("#00A6D6", 0.65), col = "white", lwd = 0.3)
    }
  }
  if (!is.null(boundary) && show_boundary_line) {
    tryCatch({
      terra::plot(boundary, add = TRUE, col = NA, border = "blue", lwd = 2)
    }, error = function(e) NULL)
  }
  graphics::mtext(sprintf("Threshold: %.2f", threshold), side = 3, adj = 1, line = 0.2, cex = 0.8)
}

plot_occurrence_map <- function(occ, species = "Species") {
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par), add = TRUE)
  graphics::par(mar = c(4, 4, 3, 1), bg = "white")

  graphics::plot.new()
  graphics::plot.window(xlim = c(-180, 180), ylim = c(-90, 90))

  tryCatch({
    world <- rnaturalearth::ne_countries(scale = 110, returnclass = "sf")
    plot(sf::st_geometry(world), col = NA, border = "black",
         lwd = 0.5, add = TRUE)
  }, error = function(e) NULL)

  graphics::axis(1, at = seq(-180, 180, 30))
  graphics::axis(2, at = seq(-90, 90, 30))

  graphics::grid(col = "grey90", lty = "dashed")

  graphics::points(occ$longitude, occ$latitude, pch = 21, cex = 1,
                   bg = "red", col = "darkred")
  graphics::title(xlab = "Longitude", ylab = "Latitude",
                  main = paste0(species, " occurrence records"))
}

save_suitability_png <- function(suitability, occ, projection_extent, species, threshold, output_png, boundary = NULL) {
  dir.create(dirname(output_png), recursive = TRUE, showWarnings = FALSE)
  grDevices::png(output_png, width = 1400, height = 900, res = 150)
  on.exit(grDevices::dev.off(), add = TRUE)
  plot_suitability_map(suitability, occ = occ, projection_extent = projection_extent, species = species, threshold = threshold, add_points = TRUE, boundary = boundary)
  invisible(output_png)
}

save_occurrence_png <- function(occ, species, output_png) {
  dir.create(dirname(output_png), recursive = TRUE, showWarnings = FALSE)
  grDevices::png(output_png, width = 1400, height = 900, res = 150)
  on.exit(grDevices::dev.off(), add = TRUE)
  plot_occurrence_map(occ, species)
  invisible(output_png)
}

plot_delta_map <- function(delta_raster, projection_extent = NULL, species = "Species") {
  old_par <- graphics::par(no.readonly = TRUE)
  on.exit(graphics::par(old_par), add = TRUE)
  graphics::par(mar = c(4, 4, 3, 5), bg = "white")

  delta_vals <- terra::values(delta_raster, na.rm = TRUE)
  cols <- colorRampPalette(c("firebrick3", "white", "forestgreen"))(255)

  terra::plot(delta_raster, col = cols, main = paste0(species, " habitat change (future - current)"),
              axes = TRUE, xlab = "Longitude", ylab = "Latitude")

  graphics::legend("right", legend = c("Loss (< 0)", "No change", "Gain (> 0)"),
                  fill = c("firebrick3", "white", "forestgreen"), bty = "n", inset = c(-0.15, 0))
}