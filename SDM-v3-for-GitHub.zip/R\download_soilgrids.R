# Download SoilGrids250m soil covariates via WebDAV.

soilgrids_base_url <- "https://files.isric.org/soilgrids/latest/data"

soilgrids_properties <- c(
  "phh2o" = "Soil pH (H2O)",
  "soc" = "Soil Organic Carbon",
  "cec" = "Cation Exchange Capacity",
  "bdod" = "Bulk Density",
  "nitrogen" = "Total Nitrogen",
  "clay" = "Clay Content",
  "sand" = "Sand Content",
  "silt" = "Silt Content"
)

soilgrids_depths <- c("0-5" = "0-5", "5-15" = "5-15", "15-30" = "15-30", "30-60" = "30-60")

get_soilgrids_depth_layers <- function(depth_cm) {
  if (depth_cm == 30) {
    c("0-5", "5-15", "15-30")
  } else if (depth_cm == 60) {
    c("0-5", "5-15", "15-30", "30-60")
  } else {
    c("0-5", "5-15", "15-30")
  }
}

download_soilgrids_tile <- function(property, depth, cache_dir, log_fun = NULL) {
  depth_str <- paste0(depth, "cm")
  filename <- paste0(property, "_", depth_str, "_mean.vrt")
  url <- file.path(soilgrids_base_url, property, filename)
  destfile <- file.path(cache_dir, paste0(property, "_", depth, "cm_mean.vrt"))

  if (file.exists(destfile)) {
    log_message(log_fun, "Using cached SoilGrids: ", basename(destfile))
    return(destfile)
  }

  log_message(log_fun, "Downloading SoilGrids: ", property, " ", depth_str)

  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)

  tryCatch({
    suppressWarnings({
      download.file(url, destfile, mode = "wb", quiet = FALSE)
    })
    destfile
  }, error = function(e) {
    log_message(log_fun, "Failed to download SoilGrids ", property, " ", depth_str, ": ", conditionMessage(e))
    NULL
  })
}

download_soilgrids_property <- function(property, depth_cm, cache_dir, log_fun = NULL) {
  layers <- get_soilgrids_depth_layers(depth_cm)
  vrt_files <- list()

  for (depth in layers) {
    vrt_file <- download_soilgrids_tile(property, depth, cache_dir, log_fun)
    if (!is.null(vrt_file)) {
      vrt_files[[depth]] <- vrt_file
    }
  }

  if (length(vrt_files) == 0) {
    return(NULL)
  }

  if (length(vrt_files) == 1) {
    return(vrt_files[[1]])
  }

  log_message(log_fun, "Averaging SoilGrids ", property, " across ", length(vrt_files), " depth layers")

  rasts <- lapply(vrt_files, terra::rast)
  stacked <- terra::rast(rasts)
  avg <- terra::app(stacked, mean, na.rm = TRUE)

  outfile <- file.path(cache_dir, paste0(property, "_", depth_cm, "cm_avg.tif"))
  terra::writeRaster(avg, outfile, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  names(avg) <- property

  outfile
}

download_soilgrids_covariates <- function(selected_properties, depth_cm = 30,
                                          cache_dir = "covariates/soilgrids",
                                          log_fun = NULL) {
  dir.create(cache_dir, recursive = TRUE, showWarnings = FALSE)

  downloaded <- list()

  for (prop in selected_properties) {
    log_message(log_fun, "Processing SoilGrids property: ", prop)

    outfile <- download_soilgrids_property(prop, depth_cm, cache_dir, log_fun)

    if (!is.null(outfile)) {
      downloaded[[prop]] <- outfile
    }
  }

  if (length(downloaded) == 0) {
    log_message(log_fun, "No SoilGrids properties were successfully downloaded")
    return(NULL)
  }

  log_message(log_fun, "Successfully downloaded ", length(downloaded), " SoilGrids properties")

  downloaded
}