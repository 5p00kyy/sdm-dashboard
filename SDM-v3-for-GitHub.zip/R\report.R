# Text report generation.

write_summary_report <- function(result, path) {
  covariates <- if (!is.null(result$environment$names)) result$environment$names else character()
  lines <- c(
    paste0("Species Distribution Model Report: ", result$config$species),
    paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
    "", "Inputs",
    paste0("- Occurrence file: ", result$config$occurrence_file),
    paste0("- WorldClim directory: ", result$config$worldclim_dir),
    paste0("- BIO variables: ", paste(paste0("BIO", result$config$selected_biovars), collapse = ", ")),
    paste0("- Covariates used: ", paste(covariates, collapse = ", ")),
    paste0("- Elevation enabled: ", isTRUE(result$config$use_elevation), if (isTRUE(result$config$use_elevation)) paste0(" (", result$config$elevation_demtype, ")") else ""),
    paste0("- Soil enabled: ", isTRUE(result$config$use_soil), if (isTRUE(result$config$use_soil)) paste0(" (", paste(result$config$selected_soil_vars, collapse = ", "), ")") else ""),
    paste0("- Training extent: ", paste(result$config$training_extent, collapse = ", ")),
    paste0("- Projection extent: ", paste(result$config$projection_extent, collapse = ", ")),
    "", "Cleaned occurrence data",
    paste0("- Valid records: ", format(nrow(result$occurrence), big.mark = ",")),
    paste0("- Sources: ", length(result$source_counts)),
    paste0("- Removed invalid coordinates: ", format(result$cleaning$removed_bad_coordinates, big.mark = ",")),
    paste0("- Removed duplicate records: ", format(result$cleaning$removed_duplicates, big.mark = ",")),
    "", "Model",
    "- Method: Fast presence/background GLM with balanced class weights",
    paste0("- Presence records used: ", format(result$metrics$presence_records, big.mark = ",")),
    paste0("- Background points used: ", format(result$metrics$background_points, big.mark = ",")),
    paste0("- CPU cores requested/used: ", result$metrics$n_cores),
    paste0("- Cross-validation AUC: ", ifelse(is.finite(result$metrics$auc_mean), sprintf("%.3f", result$metrics$auc_mean), "not run")),
    "", "Projection summary",
    paste0("- Mean suitability: ", sprintf("%.3f", result$summary$mean)),
    paste0("- Maximum suitability: ", sprintf("%.3f", result$summary$max)),
    paste0("- Cells above threshold ", result$summary$threshold, ": ", format(result$summary$cells_above_threshold, big.mark = ","), " (", sprintf("%.1f%%", result$summary$percent_above_threshold), ")"),
    paste0("- Estimated high-risk area (km2): ", ifelse(is.finite(result$summary$high_risk_area_km2), format(round(result$summary$high_risk_area_km2), big.mark = ","), "not available")),
    "", "Outputs",
    paste0("- Suitability GeoTIFF: ", result$paths$tif),
    paste0("- Suitability PNG: ", result$paths$png)
  )
  writeLines(lines, con = path)
  invisible(path)
}
