# Load and process SoilGrids250m covariates.

load_soilgrids_covariates <- function(cache_dir = "covariates/soilgrids",
                                      selected_properties = c("phh2o", "soc", "cec", "bdod", "clay", "sand", "silt"),
                                      depth_cm = 30,
                                      log_fun = NULL) {
  log_message(log_fun, "Loading SoilGrids covariates from: ", cache_dir)

  expected_files <- sapply(selected_properties, function(prop) {
    file.path(cache_dir, paste0(prop, "_", depth_cm, "cm_avg.tif"))
  })

  available_files <- expected_files[file.exists(expected_files)]

  if (length(available_files) == 0) {
    log_message(log_fun, "No cached SoilGrids files found in ", cache_dir)
    return(NULL)
  }

  missing <- setdiff(names(expected_files), names(available_files))
  if (length(missing) > 0) {
    log_message(log_fun, "Missing SoilGrids files: ", paste(missing, collapse = ", "))
  }

  rasts <- lapply(available_files, function(f) {
    r <- terra::rast(f)
    r
  })

  soil_stack <- terra::rast(rasts)

  methods <- rep("bilinear", length(selected_properties))
  names(methods) <- selected_properties

  log_message(log_fun, "Loaded ", terra::nlyr(soil_stack), " SoilGrids soil layer(s)")

  list(
    raster = soil_stack,
    files = unlist(available_files),
    source = "SoilGrids250m (ISRIC)",
    variables = selected_properties,
    methods = methods,
    depth_cm = depth_cm
  )
}

get_soilgrids_property_info <- function() {
  list(
    properties = list(
      "phh2o" = list(name = "Soil pH (H2O)", unit = "pH", priority = "high", conversion = 0.1),
      "soc" = list(name = "Soil Organic Carbon", unit = "g/kg", priority = "high", conversion = 0.1),
      "cec" = list(name = "Cation Exchange Capacity", unit = "cmol/kg", priority = "high", conversion = 0.1),
      "bdod" = list(name = "Bulk Density", unit = "kg/dm3", priority = "high", conversion = 0.01),
      "nitrogen" = list(name = "Total Nitrogen", unit = "g/kg", priority = "medium", conversion = 0.1),
      "clay" = list(name = "Clay Content", unit = "%", priority = "medium", conversion = 0.1),
      "sand" = list(name = "Sand Content", unit = "%", priority = "medium", conversion = 0.1),
      "silt" = list(name = "Silt Content", unit = "%", priority = "medium", conversion = 0.1)
    ),
    depth_options = c("30" = "0-30 cm", "60" = "0-60 cm"),
    default_properties = c("phh2o", "soc", "cec", "bdod"),
    default_depth = "30"
  )
}