# Custom Rangebag SDM implementation (Drake 2015 algorithm).

sample_background_points_rb <- function(env_train, n, seed = 42) {
  seed <- as.integer(seed)
  if (is.na(seed) || seed < 1) seed <- 42
  set.seed(seed)
  n <- as.integer(n)
  if (is.na(n) || n < 100) n <- 100
  pts <- try(terra::spatSample(env_train[[1]], size = n, method = "random", na.rm = TRUE, xy = TRUE, cells = TRUE, as.points = FALSE, values = FALSE), silent = TRUE)
  if (inherits(pts, "try-error") || is.null(pts) || nrow(as.data.frame(pts)) == 0 || !all(c("x", "y") %in% names(as.data.frame(pts)))) {
    values <- terra::values(env_train[[1]], mat = FALSE)
    valid_cells <- which(!is.na(values))
    if (length(valid_cells) == 0) stop("No valid background cells available in the training raster.", call. = FALSE)
    cells <- sample(valid_cells, size = min(n, length(valid_cells)), replace = length(valid_cells) < n)
    xy <- as.data.frame(terra::xyFromCell(env_train[[1]], cells))
    names(xy) <- c("x", "y")
  } else {
    pts <- as.data.frame(pts)
    xy <- pts[, c("x", "y"), drop = FALSE]
  }
  xy
}

extract_covariates_rb <- function(r, xy) {
  vals <- terra::extract(r, xy)
  if ("ID" %in% names(vals)) vals <- vals[, setdiff(names(vals), "ID"), drop = FALSE]
  vals
}

.auc_internal <- function(obs, pred) {
  obs <- as.integer(obs)
  pred <- as.numeric(pred)
  ok <- is.finite(obs) & is.finite(pred)
  obs <- obs[ok]
  pred <- pred[ok]
  n1 <- sum(obs == 1)
  n0 <- sum(obs == 0)
  if (n1 == 0 || n0 == 0) return(NA_real_)
  r <- rank(pred, ties.method = "average")
  as.numeric((sum(r[obs == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0))
}

has_geometry <- function() {
  tryCatch({
    requireNamespace("geometry", quietly = TRUE)
  }, error = function(e) FALSE)
}

find_optimal_threshold_rb <- function(obs, pred) {
  pred_sorted <- sort(pred)
  n <- length(pred_sorted)
  if (n < 3) return(0.5)
  candidates <- pred_sorted[2:(n-1)]
  if (length(candidates) < 1) return(0.5)
  best_thresh <- 0.5
  best_tss <- -Inf
  n_pres <- sum(obs == 1)
  n_bg <- sum(obs == 0)
  if (n_pres < 1 || n_bg < 1) return(0.5)
  for (t in candidates) {
    sens <- sum(obs[pred >= t] == 1, na.rm = TRUE) / n_pres
    spec <- sum(obs[pred < t] == 0, na.rm = TRUE) / n_bg
    tss <- sens + spec - 1
    if (tss > best_tss) {
      best_tss <- tss
      best_thresh <- t
    }
  }
  best_thresh
}

create_bag <- function(data, p = 0.5, d = 2, seed = NULL) {
  n <- nrow(data)
  if (n < 3) stop("Need at least 3 points to create bag")

  n_sample <- max(ceiling(n * p), 3)
  if (n_sample > n) n_sample <- n

  if (!is.null(seed)) set.seed(seed)

  idx <- sample(n, size = n_sample, replace = FALSE)
  bag_data <- data[idx, , drop = FALSE]

  n_vars <- ncol(data)
  d_use <- min(d, n_vars)
  var_idx <- sample(n_vars, size = d_use, replace = FALSE)
  bag_vars <- bag_data[, var_idx, drop = FALSE]

  if (d_use == 1 || length(var_idx) == 1) {
    rng <- c(min(bag_vars), max(bag_vars))
    if (is.na(rng[1]) || is.na(rng[2])) stop("Invalid range from bag data")
    structure(list(vars = var_idx, range = rng, type = "1d"), class = "rangebag_bag")
  } else {
    hull_try <- tryCatch({
      if (has_geometry()) {
        hull_pts <- unique(as.matrix(bag_vars))
        if (nrow(hull_pts) >= 3) {
          hull_idx <- geometry::convhulln(hull_pts, options = "Pp")
          list(success = TRUE, points = hull_pts, idx = as.integer(hull_idx))
        } else {
          list(success = FALSE, reason = "not enough unique points for hull")
        }
      } else {
        list(success = FALSE, reason = "geometry package not available")
      }
    }, error = function(e) list(success = FALSE, reason = paste("hull error:", conditionMessage(e))))

    if (hull_try$success) {
      structure(list(vars = var_idx, hull = hull_try, type = "hull"), class = "rangebag_bag")
    } else {
      rngs <- apply(bag_vars, 2, function(x) c(min(x), max(x)))
      structure(list(vars = var_idx, ranges = rngs, type = "box"), class = "rangebag_bag")
    }
  }
}

predict_bag <- function(bag, newdata) {
  var_idx <- bag$vars
  new_vars <- newdata[, var_idx, drop = FALSE]

  if (bag$type == "1d") {
    rng <- bag$range
    in_range <- new_vars[, 1] >= rng[1] & new_vars[, 1] <= rng[2]
    as.integer(in_range)
  } else if (bag$type == "hull") {
    tryCatch({
      pts <- as.matrix(new_vars)
      hull_pts <- bag$hull$points
      tri <- geometry::delaunayn(hull_pts)
      inside <- !is.na(geometry::tsearchn(hull_pts, tri, pts)$p[, 1])
      as.integer(inside)
    }, error = function(e) {
      rngs <- bag$ranges
      in_box <- rowSums(sweep(new_vars, 2, rngs[, 1], ">=")) + rowSums(sweep(new_vars, 2, rngs[, 2], "<=")) == 2 * length(var_idx)
      as.integer(in_box)
    })
  } else {
    rngs <- bag$ranges
    in_box <- rowSums(sweep(new_vars, 2, rngs[, 1], ">=")) + rowSums(sweep(new_vars, 2, rngs[, 2], "<=")) == 2 * length(var_idx)
    as.integer(in_box)
  }
}

fit_rangebag_sdm <- function(occ, env_train, env_train_scaled, background_n = 10000,
                             n_bags = 100, cv_folds = 5, seed = 42, n_cores = 1,
                             log_fun = NULL, threshold = 0.5, d = 1, p = 0.5,
                             force_2d = FALSE) {
  log_message(log_fun, "fit_rangebag_sdm: Starting custom rangebagging implementation")

  d_requested <- d
  if (d != 1 && d != 2) {
    log_message(log_fun, "WARNING: d must be 1 or 2, setting to 1")
    d <- 1
  }

  ensure_sdm_packages(c("terra", "geometry"), n_cores = n_cores)
  covariates <- names(env_train_scaled)
  if (length(covariates) < 2) stop("At least two covariates are required for modelling.", call. = FALSE)

  seed <- as.integer(seed)
  if (is.na(seed) || seed < 1) seed <- 42
  set.seed(seed)

  log_message(log_fun, "Fitting Custom Rangebagging: n_bags=", n_bags, ", d=", d,
              " (requested d=", d_requested, "), p=", p, ", cv_folds=", cv_folds,
              ", force_2d=", force_2d)

  dimension_used <- d
  failed_hulls <- 0
  global_fallback_triggered <- FALSE

  pres_xy <- occ[, c("longitude", "latitude"), drop = FALSE]
  names(pres_xy) <- c("x", "y")
  pres_vals <- extract_covariates_rb(env_train_scaled, pres_xy)
  pres_keep <- stats::complete.cases(pres_vals)
  if (sum(!pres_keep) > 0) log_message(log_fun, "Dropping ", sum(!pres_keep), " occurrence records with missing covariates")
  pres_vals <- as.data.frame(pres_vals[pres_keep, , drop = FALSE])
  occ_used <- occ[pres_keep, , drop = FALSE]
  if (nrow(pres_vals) < 20) stop("Too few presence records with complete environmental data.", call. = FALSE)

  log_message(log_fun, "Rangebag: Sampling background points")
  bg_xy <- sample_background_points_rb(env_train, background_n, seed = seed)
  log_message(log_fun, "Rangebag: Extracting background covariates")
  bg_vals <- extract_covariates_rb(env_train_scaled, bg_xy)
  bg_keep <- stats::complete.cases(bg_vals)
  bg_vals <- as.data.frame(bg_vals[bg_keep, , drop = FALSE])
  bg_xy <- bg_xy[bg_keep, , drop = FALSE]
  if (nrow(bg_vals) < 100) stop("Too few background points could be sampled.", call. = FALSE)
  log_message(log_fun, "Rangebag: ", nrow(pres_vals), " presences, ", nrow(bg_vals), " background points")

  cv_scores <- list()
  k <- cv_folds
  if (cv_folds > 1) {
    k <- min(cv_folds, nrow(pres_vals))
    if (k < 2) k <- 2
    fold_id <- sample(rep(seq_len(k), length.out = nrow(pres_vals)))
    log_message(log_fun, "Running ", k, "-fold cross-validation")

    for (fold_i in seq_len(k)) {
      train_idx <- which(fold_id != fold_i)
      test_idx <- which(fold_id == fold_i)
      train_pres <- pres_vals[train_idx, , drop = FALSE]
      test_pres <- pres_vals[test_idx, , drop = FALSE]
      test_bg <- bg_vals

      fold_d <- d
      if (global_fallback_triggered) {
        fold_d <- 1
        log_message(log_fun, "Fold ", fold_i, ": Using fallback 1D (global fallback triggered)")
      }

      log_message(log_fun, "Rangebag CV fold ", fold_i, ": Creating ", n_bags, " bags with d=", fold_d)
      bags <- list()
      fold_failed_2d <- 0

      for (b in 1:n_bags) {
        bag_result <- tryCatch(
          create_bag(train_pres, p = p, d = fold_d, seed = seed + b * 1000 + fold_i),
          error = function(e) {
            log_message(log_fun, paste0("Bag ", b, " failed: ", conditionMessage(e)))
            NULL
          }
        )

        if (is.null(bag_result)) {
          if (fold_d == 2 && !global_fallback_triggered) {
            fold_failed_2d <- fold_failed_2d + 1
            log_message(log_fun, paste0("Bag ", b, " 2D failed, trying 1D fallback"))
          }
          bag_result <- tryCatch(
            create_bag(train_pres, p = p, d = 1, seed = seed + b * 1000 + fold_i),
            error = function(e) {
              log_message(log_fun, paste0("Fallback bag also failed: ", conditionMessage(e)))
              NULL
            }
          )
        }

        if (!is.null(bag_result) && fold_d == 2 && is.null(bag_result$hull) && bag_result$type == "box") {
          fold_failed_2d <- fold_failed_2d + 1
        }

        bags[[b]] <- bag_result
      }

      if (fold_d == 2 && fold_failed_2d > 0 && !global_fallback_triggered && !force_2d) {
        global_fallback_triggered <- TRUE
        log_message(log_fun, paste0("WARNING: 2D path failed for ", fold_failed_2d, " bags in fold ", fold_i, " - GLOBAL FALLBACK triggered, switching to 1D for remaining folds"))
        dimension_used <- 1
      }

      bags <- Filter(Negate(is.null), bags)
      if (length(bags) < 1) {
        log_message(log_fun, "No bags created successfully for CV fold ", fold_i)
        next
      }
      log_message(log_fun, "Successfully created ", length(bags), " bags, ", fold_failed_2d, " 2D fallbacks in this fold")

      test_data <- rbind(test_pres, test_bg)
      test_response <- c(rep(1, nrow(test_pres)), rep(0, nrow(test_bg)))

      votes <- rep(0, nrow(test_data))
      for (b in seq_along(bags)) {
        votes <- votes + predict_bag(bags[[b]], test_data)
      }
      pred_test <- votes / n_bags

      if (is.numeric(pred_test) && !all(is.na(pred_test))) {
        auc_val <- .auc_internal(test_response, pred_test)
        opt_thresh <- find_optimal_threshold_rb(test_response, pred_test)
        pres_pred <- pred_test[1:nrow(test_pres)]
        bg_pred <- pred_test[(nrow(test_pres) + 1):length(pred_test)]
        sens <- sum(pres_pred >= opt_thresh, na.rm = TRUE) / length(pres_pred)
        spec <- sum(bg_pred < opt_thresh, na.rm = TRUE) / length(bg_pred)
        tss_val <- sens + spec - 1
        cv_scores[[fold_i]] <- c(auc = auc_val, tss = tss_val, opt_thresh = opt_thresh)
        log_message(log_fun, paste0("Fold ", fold_i, ": AUC=", sprintf("%.3f", auc_val), ", TSS=", sprintf("%.3f", tss_val), " (thresh=", sprintf("%.3f", opt_thresh), ")"))
      }
    }
  }

  auc_mean <- NA_real_
  auc_sd <- NA_real_
  tss_mean <- NA_real_
  tss_sd <- NA_real_
  opt_threshold_mean <- 0.5
  if (length(cv_scores) > 0) {
    auc_vals <- na.omit(sapply(cv_scores, `[[`, "auc"))
    tss_vals <- na.omit(sapply(cv_scores, `[[`, "tss"))
    if (length(auc_vals) > 0) {
      auc_mean <- mean(auc_vals)
      auc_sd <- sd(auc_vals)
    }
    if (length(tss_vals) > 0) {
      tss_mean <- mean(tss_vals)
      tss_sd <- sd(tss_vals)
    }
    log_message(log_fun, "Rangebag CV AUC: ", sprintf("%.3f", auc_mean), if (is.finite(auc_sd)) paste0(" +/- ", sprintf("%.3f", auc_sd)) else "")
    log_message(log_fun, "Rangebag CV TSS: ", sprintf("%.3f", tss_mean), if (is.finite(tss_sd)) paste0(" +/- ", sprintf("%.3f", tss_sd)) else "")
    thresh_vals <- na.omit(sapply(cv_scores, `[[`, "opt_thresh"))
    opt_threshold_mean <- if (length(thresh_vals) > 0) mean(thresh_vals) else 0.5
    log_message(log_fun, "Rangebag calibrated threshold: ", sprintf("%.3f", opt_threshold_mean))
  }

  log_message(log_fun, "Training final Rangebag model with ", n_bags, " bags")

  final_d <- d
  if (global_fallback_triggered) {
    final_d <- 1
    log_message(log_fun, "Global fallback active: using d=1 for final model")
  }

  final_bags <- list()
  final_fallback_count <- 0
  for (b in 1:n_bags) {
    bag_result <- tryCatch(
      create_bag(pres_vals, p = p, d = final_d, seed = seed + b * 1000),
      error = function(e) {
        log_message(log_fun, paste0("Final bag ", b, " failed: ", conditionMessage(e)))
        NULL
      }
    )
    if (is.null(bag_result)) {
      bag_result <- tryCatch(
        create_bag(pres_vals, p = p, d = 1, seed = seed + b * 1000),
        error = function(e) NULL
      )
      final_fallback_count <- final_fallback_count + 1
    }
    final_bags[[b]] <- bag_result
    if (b %% 20 == 0) log_message(log_fun, "Created bag ", b, " of ", n_bags)
  }

  final_bags <- Filter(Negate(is.null), final_bags)
  log_message(log_fun, "Final model: ", length(final_bags), " bags, ", final_fallback_count, " fallbacks from ", final_d, "D")

  if (global_fallback_triggered || final_fallback_count > 0) {
    log_message(log_fun, "WARNING: 2D path failed - global fallback triggered. Using 1D ranges.")
  }

  model_data <- list(
    bags = final_bags,
    d_requested = d_requested,
    d_used = final_d,
    p = p,
    n_bags = n_bags,
    covariates = covariates,
    global_fallback_triggered = global_fallback_triggered,
    fallback_count = final_fallback_count,
    calibrated_threshold = opt_threshold_mean
  )

  list(
    model = model_data,
    model_type = "rangebag",
    cv = list(k = k, auc_mean = auc_mean, auc_sd = auc_sd, tss_mean = tss_mean, tss_sd = tss_sd, opt_threshold = opt_threshold_mean, fold_scores = cv_scores),
    occurrence_used = occ_used,
    background_xy = bg_xy,
    covariates = covariates,
    means = attr(env_train_scaled, "means"),
    sds = attr(env_train_scaled, "sds"),
    dimension_info = list(requested = d_requested, used = final_d, global_fallback = global_fallback_triggered, fallback_count = final_fallback_count)
  )
}

predict_rangebag <- function(rb_model, env_scaled, output_tif, n_cores = 1, log_fun = NULL) {
  log_message(log_fun, "Predicting suitability with Custom Rangebag")
  log_message(log_fun, "Model type: ", rb_model$model_type)

  if (!is.null(rb_model$dimension_info)) {
    log_message(log_fun, "Dimension info: requested=", rb_model$dimension_info$requested,
                ", used=", rb_model$dimension_info$used,
                ", fallback=", rb_model$dimension_info$global_fallback)
  }

  dir.create(dirname(output_tif), recursive = TRUE, showWarnings = FALSE)

  env_df <- as.data.frame(env_scaled, xy = FALSE)
  n_cells <- nrow(env_df)
  log_message(log_fun, "Predicting to ", n_cells, " raster cells")

  model_data <- rb_model$model
  bags <- model_data$bags
  n_bags <- length(bags)
  log_message(log_fun, "Using ", n_bags, " bags for prediction")

  votes <- rep(0, n_cells)
  for (b in seq_along(bags)) {
    bag_votes <- predict_bag(bags[[b]], env_df)
    votes <- votes + bag_votes
    if (b %% 20 == 0) log_message(log_fun, "Predicted with bag ", b, " of ", n_bags)
  }

  suit_values <- votes / n_bags
  suit <- terra::setValues(env_scaled[[1]], suit_values)
  names(suit) <- "suitability"

  terra::writeRaster(suit, output_tif, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  log_message(log_fun, "Saved rangebag prediction to: ", output_tif)
  suit
}