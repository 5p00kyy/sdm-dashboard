# Ensemble SDM (GLM + Rangebag) fitting and combination.

fit_ensemble_sdm <- function(occ, env_train, env_train_scaled, background_n = 10000,
                             include_quadratic = FALSE, n_bags = 100,
                             cv_folds = 5, seed = 42, n_cores = 1,
                             ensemble_weighting = "tss", tss_threshold = 0.6,
                             log_fun = NULL, threshold = 0.5,
                             d = 1, force_2d = FALSE, ...) {
  log_message(log_fun, "=== Fitting GLM component of ensemble ===")
  glm_result <- fit_fast_sdm(occ, env_train_scaled, background_n, include_quadratic,
                            cv_folds, seed, n_cores, log_fun)
  log_message(log_fun, "=== Fitting Rangebag component of ensemble (d=", d, ") ===")
  rb_result <- fit_rangebag_sdm(occ, env_train, env_train_scaled, background_n,
                                n_bags, cv_folds, seed, n_cores, log_fun, threshold, d = d, force_2d = force_2d)

  glm_cv_ok <- !is.null(glm_result$cv) && !is.null(glm_result$cv$auc_mean) && is.finite(glm_result$cv$auc_mean)
  glm_auc <- if (glm_cv_ok) glm_result$cv$auc_mean else 0.5

  if (!is.null(glm_result$cv) && !is.null(glm_result$cv$tss_mean) && is.finite(glm_result$cv$tss_mean)) {
    glm_tss <- glm_result$cv$tss_mean
  } else {
    glm_tss <- 2 * glm_auc - 1
    glm_tss <- max(glm_tss, 0)
  }

  rb_cv_ok <- !is.null(rb_result$cv) && !is.null(rb_result$cv$auc_mean) && is.finite(rb_result$cv$auc_mean)
  rb_auc <- if (rb_cv_ok) rb_result$cv$auc_mean else 0.5

  if (!is.null(rb_result$cv) && !is.null(rb_result$cv$tss_mean) && is.finite(rb_result$cv$tss_mean)) {
    rb_tss <- rb_result$cv$tss_mean
  } else {
    rb_tss <- 0.5
  }

  glm_passed <- !is.na(glm_tss) && glm_tss >= tss_threshold
  rb_passed <- !is.na(rb_tss) && rb_tss >= tss_threshold

  log_message(log_fun, paste0("GLM TSS: ", sprintf("%.3f", glm_tss), " (threshold: ", tss_threshold, ") - ", if (glm_passed) "PASSED" else "FAILED"))
  log_message(log_fun, paste0("Rangebag TSS: ", sprintf("%.3f", rb_tss), " (threshold: ", tss_threshold, ") - ", if (rb_passed) "PASSED" else "FAILED"))

  glm_weight <- 0
  rb_weight <- 0

  if (glm_passed && rb_passed) {
    if (ensemble_weighting == "tss") {
      total_tss <- glm_tss + rb_tss
      glm_weight <- glm_tss / total_tss
      rb_weight <- rb_tss / total_tss
    } else if (ensemble_weighting == "auc") {
      total_auc <- glm_auc + rb_auc
      glm_weight <- glm_auc / total_auc
      rb_weight <- rb_auc / total_auc
    } else {
      glm_weight <- 0.5
      rb_weight <- 0.5
    }
    log_message(log_fun, sprintf("Ensemble weights: GLM=%.2f, Rangebag=%.2f", glm_weight, rb_weight))
  } else if (glm_passed && !rb_passed) {
    log_message(log_fun, "Rangebag failed TSS threshold - using GLM only")
    glm_weight <- 1.0
    rb_weight <- 0.0
  } else if (!glm_passed && rb_passed) {
    log_message(log_fun, "GLM failed TSS threshold - using Rangebag only")
    glm_weight <- 0.0
    rb_weight <- 1.0
  } else {
    log_message(log_fun, "WARNING: Both models failed TSS threshold - using equal weights")
    glm_weight <- 0.5
    rb_weight <- 0.5
  }

  list(
    glm_model = glm_result$model,
    glm_cv = glm_result$cv,
    glm_occurrence_used = glm_result$occurrence_used,
    glm_coefficients = glm_result$coefficients,
    rb_model = rb_result,
    rb_cv = rb_result$cv,
    rb_occurrence_used = rb_result$occurrence_used,
    weights = c(glm = glm_weight, rangebag = rb_weight),
    model_type = "ensemble",
    include_quadratic = include_quadratic,
    cv = list(
      k = cv_folds,
      glm_auc = glm_auc,
      glm_tss = glm_tss,
      rb_auc = rb_auc,
      rb_tss = rb_tss,
      ensemble_weights = c(glm = glm_weight, rangebag = rb_weight)
    ),
    occurrence_used = glm_result$occurrence_used,
    background_xy = glm_result$background_xy,
    covariates = glm_result$covariates,
    threshold = threshold,
    tss_threshold_used = tss_threshold,
    weighting_method = ensemble_weighting
  )
}

predict_ensemble <- function(ensemble_result, env_scaled, output_dir,
                              species, n_cores = 1, log_fun = NULL) {
  log_message(log_fun, "predict_ensemble: Starting")
  log_message(log_fun, "predict_ensemble: env_scaled class = ", class(env_scaled)[1], ", nlayers = ", terra::nlyr(env_scaled))
  log_message(log_fun, "predict_ensemble: glm_model class = ", class(ensemble_result$glm_model)[1])
  log_message(log_fun, "predict_ensemble: rb_model class = ", class(ensemble_result$rb_model)[1])

  base_name <- safe_slug(species)
  glm_tif <- file.path(output_dir, paste0(base_name, "_glm_suitability.tif"))
  rb_tif <- file.path(output_dir, paste0(base_name, "_rangebag_suitability.tif"))
  ens_tif <- file.path(output_dir, paste0(base_name, "_ensemble_suitability.tif"))
  log_message(log_fun, "Predicting GLM component")
  glm_suit <- predict_suitability(ensemble_result$glm_model, env_scaled, glm_tif, n_cores, log_fun)
  log_message(log_fun, "Predicting Rangebag component")
  rb_suit <- predict_rangebag(ensemble_result$rb_model, env_scaled, rb_tif, n_cores, log_fun)
  w_glm <- ensemble_result$weights["glm"]
  w_rb <- ensemble_result$weights["rangebag"]
  log_message(log_fun, sprintf("Computing ensemble (GLM: %.2f, RB: %.2f)", w_glm, w_rb))
  ensemble_suit <- (glm_suit * w_glm) + (rb_suit * w_rb)
  names(ensemble_suit) <- "suitability"
  terra::writeRaster(ensemble_suit, ens_tif, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  list(
    glm_suitability = glm_suit,
    rb_suitability = rb_suit,
    ensemble_suitability = ensemble_suit,
    paths = list(glm = glm_tif, rangebag = rb_tif, ensemble = ens_tif),
    weights = ensemble_result$weights
  )
}