# Raster prediction and suitability summary helpers.

predict_suitability <- function(model, env_project_scaled, output_tif, n_cores = 1, log_fun = NULL, boundary = NULL) {
  dir.create(dirname(output_tif), recursive = TRUE, showWarnings = FALSE)
  n_cores <- normalize_core_count(n_cores)
  log_message(log_fun, "Predicting suitability raster with ", n_cores, " core(s)")
  log_message(log_fun, "Model class: ", class(model)[1])
  log_message(log_fun, "Env class: ", class(env_project_scaled)[1])
  log_message(log_fun, "Env nlayers: ", terra::nlyr(env_project_scaled))
  predict_args <- list(object = env_project_scaled, model = model, type = "response", na.rm = TRUE,
                       filename = output_tif, overwrite = TRUE,
                       wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  if (n_cores > 1) predict_args$cores <- n_cores
  suit <- tryCatch(do.call(terra::predict, predict_args), error = function(e) {
    if (n_cores > 1) {
      log_message(log_fun, "Parallel terra prediction fell back to single-core mode: ", conditionMessage(e))
      predict_args$cores <- NULL
      suit <- tryCatch(do.call(terra::predict, predict_args), error = function(e2) stop(e2))
    } else {
      log_message(log_fun, "GLM/terra prediction failed: ", conditionMessage(e))
      stop(e)
    }
  })
  names(suit) <- "suitability"
  suit
}

summarise_suitability <- function(suitability, threshold = 0.5) {
  vals <- terra::values(suitability, na.rm = TRUE, mat = FALSE)
  threshold <- normalize_threshold(threshold)
  if (length(vals) == 0) {
    return(list(cell_count = 0, mean = NA_real_, median = NA_real_, max = NA_real_, threshold = threshold,
                cells_above_threshold = 0, percent_above_threshold = NA_real_, high_risk_area_km2 = NA_real_))
  }
  risk_cells <- sum(vals >= threshold, na.rm = TRUE)
  high_risk_area <- try({
    area <- terra::cellSize(suitability, unit = "km")
    area_risk <- terra::ifel(suitability >= threshold, area, NA)
    as.numeric(terra::global(area_risk, "sum", na.rm = TRUE)[1, 1])
  }, silent = TRUE)
  if (inherits(high_risk_area, "try-error")) high_risk_area <- NA_real_
  list(cell_count = length(vals), mean = mean(vals, na.rm = TRUE), median = stats::median(vals, na.rm = TRUE),
       max = max(vals, na.rm = TRUE), threshold = threshold, cells_above_threshold = risk_cells,
       percent_above_threshold = 100 * risk_cells / length(vals), high_risk_area_km2 = high_risk_area)
}

summarise_suitability_by_boundary <- function(suitability, boundary, threshold = 0.5) {
  if (is.null(boundary)) {
    return(NULL)
  }
  cropped <- tryCatch(terra::crop(suitability, boundary), error = function(e) NULL)
  if (is.null(cropped)) {
    return(list(cell_count = 0, mean = NA_real_, median = NA_real_, max = NA_real_, threshold = threshold,
                cells_above_threshold = 0, percent_above_threshold = NA_real_, high_risk_area_km2 = NA_real_))
  }
  summarise_suitability(cropped, threshold)
}

predict_future_suitability <- function(current_result, future_dir, selected_biovars,
                                         projection_extent, aggregation_factor = 1,
                                         cmip6_models = "ACCESS-CM2", cmip6_ssp = "585",
                                         cmip6_time = "2061-2080", n_cores = NULL, log_fun = NULL) {
  ensure_sdm_packages("terra", n_cores = n_cores)
  n_cores <- normalize_core_count(n_cores)

  if (length(cmip6_models) == 1) {
    cmip6_models <- cmip6_models[1]
  }

  if (length(cmip6_models) > 1) {
    log_message(log_fun, "Running multi-model ensemble with ", length(cmip6_models), " GCMs: ", paste(cmip6_models, collapse = ", "))
  } else {
    log_message(log_fun, "Loading future climate (", cmip6_models, ", SSP", cmip6_ssp, ", ", cmip6_time, ")")
  }

  means <- current_result$environment$means
  sds <- current_result$environment$sds
  template <- current_result$suitability

  individual_suitabilities <- list()
  individual_deltas <- list()
  individual_paths <- list()

  for (gcm in cmip6_models) {
    log_message(log_fun, "Processing GCM: ", gcm)
    future_env <- load_future_climate_covariates(
      future_dir, selected_biovars, projection_extent, aggregation_factor,
      allow_download = TRUE, model = gcm, ssp = cmip6_ssp, time = cmip6_time,
      worldclim_res = 10, log_fun = log_fun, n_cores = n_cores
    )

    available_names <- names(future_env$env_project)
    keep_vars <- intersect(names(means), available_names)
    if (length(keep_vars) < 2) {
      log_message(log_fun, "Skipping ", gcm, " - insufficient matching covariates")
      next
    }

    future_env_scaled <- scale_raster_stack(future_env$env_project[[keep_vars]], means[keep_vars], sds[keep_vars])

    base_name <- paste0(safe_slug(current_result$config$species), "_future_", gcm, "_ssp", cmip6_ssp, "_", gsub("-", "", cmip6_time))
    output_tif <- file.path(dirname(current_result$paths$tif), paste0(base_name, "_suitability.tif"))
    output_tif_delta <- file.path(dirname(current_result$paths$tif), paste0(base_name, "_delta.tif"))

    future_suit <- predict_suitability(current_result$model, future_env_scaled, output_tif, n_cores, log_fun)
    delta_suit <- future_suit - current_result$suitability
    terra::writeRaster(delta_suit, output_tif_delta, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
    names(delta_suit) <- "suitability_change"

    individual_suitabilities[[gcm]] <- future_suit
    individual_deltas[[gcm]] <- delta_suit
    individual_paths[[gcm]] <- list(tif = output_tif, delta = output_tif_delta)
  }

  if (length(individual_suitabilities) == 0) {
    stop("No GCMs could be processed successfully", call. = FALSE)
  }

  log_message(log_fun, "Computing ensemble average")
  ensemble_suit <- terra::app(terra::rast(individual_suitabilities), mean, na.rm = TRUE)
  ensemble_delta <- terra::app(terra::rast(individual_deltas), mean, na.rm = TRUE)

  base_name <- if (length(cmip6_models) > 1) {
    paste0(safe_slug(current_result$config$species), "_future_ensemble_ssp", cmip6_ssp, "_", gsub("-", "", cmip6_time))
  } else {
    paste0(safe_slug(current_result$config$species), "_future_", cmip6_models[1], "_ssp", cmip6_ssp, "_", gsub("-", "", cmip6_time))
  }
  output_tif_ensemble <- file.path(dirname(current_result$paths$tif), paste0(base_name, "_suitability.tif"))
  output_tif_delta_ensemble <- file.path(dirname(current_result$paths$tif), paste0(base_name, "_delta.tif"))

  terra::writeRaster(ensemble_suit, output_tif_ensemble, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  terra::writeRaster(ensemble_delta, output_tif_delta_ensemble, overwrite = TRUE, wopt = list(gdal = c("COMPRESS=LZW", "TILED=YES")))
  names(ensemble_delta) <- "suitability_change"

  future_summary <- summarise_suitability(ensemble_suit, current_result$config$threshold)
  delta_summary <- summarise_suitability(ensemble_delta, 0)

  model_label <- if (length(cmip6_models) > 1) {
    paste0("Ensemble (", paste(cmip6_models, collapse = ", "), ")")
  } else {
    cmip6_models[1]
  }

  list(
    suitability = ensemble_suit, summary = future_summary,
    delta = ensemble_delta, delta_summary = delta_summary,
    scenario = list(model = model_label, ssp = cmip6_ssp, time = cmip6_time, models = cmip6_models),
    paths = list(tif = output_tif_ensemble, delta = output_tif_delta_ensemble),
    individual = list(
      suitabilities = individual_suitabilities,
      deltas = individual_deltas,
      paths = individual_paths
    )
  )
}
