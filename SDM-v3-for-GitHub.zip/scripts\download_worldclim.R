#!/usr/bin/env Rscript
# Download/recreate local WorldClim BIO raster files.

source("R/optimized_sdm.R")
source("R/load.R")

args <- commandArgs(trailingOnly = TRUE)
res <- if (length(args) >= 1) as.numeric(args[[1]]) else 10
biovars <- if (length(args) >= 2) as.integer(strsplit(args[[2]], ",")[[1]]) else 1:19
n_cores <- max(1L, detect_available_cores(TRUE) - 1L)

download_worldclim_layers(
  worldclim_dir = "Worldclim",
  selected_biovars = biovars,
  res = res,
  n_cores = n_cores
)

cat("WorldClim layers checked/downloaded in Worldclim/\n")
