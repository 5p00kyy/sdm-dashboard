# WorldClim discovery, download, cropping, and scaling helpers.

find_worldclim_files <- function(worldclim_dir, selected_biovars) {
  files <- if (dir.exists(worldclim_dir)) list.files(worldclim_dir, pattern = "\\.tif$", full.names = TRUE, recursive = TRUE) else character()
  selected_biovars <- as.integer(selected_biovars)
  if (length(files) == 0) return(setNames(rep(NA_character_, length(selected_biovars)), selected_biovars))
  matched <- vapply(selected_biovars, function(bv) {
    pattern <- sprintf("bio_?%d\\.tif$", bv)
    hit <- files[grepl(pattern, basename(files), ignore.case = TRUE, perl = TRUE)]
    if (length(hit) == 0) NA_character_ else hit[1]
  }, character(1))
  matched
}

download_worldclim_layers <- function(worldclim_dir, selected_biovars, res = 10, log_fun = NULL, n_cores = NULL) {
  ensure_sdm_packages(c("terra", "geodata"), n_cores = n_cores)
  dir.create(worldclim_dir, recursive = TRUE, showWarnings = FALSE)
  log_message(log_fun, "Downloading WorldClim BIO layers to ", worldclim_dir, " (resolution ", res, " arc-min)")
  wc <- geodata::worldclim_global(var = "bio", res = res, path = worldclim_dir)
  for (bv in as.integer(selected_biovars)) {
    idx <- grep(sprintf("bio_?%d$", bv), names(wc), ignore.case = TRUE)
    if (length(idx) == 0 && bv <= terra::nlyr(wc)) idx <- bv
    if (length(idx) > 0) {
      out <- file.path(worldclim_dir, sprintf("wc2.1_%sm_bio_%d.tif", res, bv))
      if (!file.exists(out)) try(terra::writeRaster(wc[[idx[1]]], out, overwrite = TRUE), silent = TRUE)
    }
  }
  invisible(find_worldclim_files(worldclim_dir, selected_biovars))
}

crop_and_optionally_aggregate <- function(r, extent_vec, aggregation_factor = 1, boundary = NULL) {
  if (!is.null(boundary)) {
    cropped <- terra::crop(r, boundary, snap = "out")
  } else {
    cropped <- terra::crop(r, terra::ext(extent_vec[1], extent_vec[2], extent_vec[3], extent_vec[4]), snap = "out")
  }
  aggregation_factor <- as.integer(aggregation_factor)
  if (is.na(aggregation_factor) || aggregation_factor < 1) aggregation_factor <- 1
  if (aggregation_factor > 1) cropped <- terra::aggregate(cropped, fact = aggregation_factor, fun = mean, na.rm = TRUE)
  cropped
}

scale_raster_stack <- function(r, means, sds) {
  out <- r
  layer_names <- names(r)
  for (i in seq_len(terra::nlyr(r))) {
    nm <- layer_names[i]
    m <- if (!is.null(names(means)) && nm %in% names(means)) means[[nm]] else means[i]
    s <- if (!is.null(names(sds))   && nm %in% names(sds))   sds[[nm]]   else sds[i]
    out[[i]] <- (r[[i]] - m) / s
  }
  names(out) <- layer_names
  out
}

load_climate_covariates <- function(worldclim_dir, selected_biovars, training_extent, projection_extent,
                                    aggregation_factor = 1, allow_download = TRUE, worldclim_res = 10,
                                    log_fun = NULL, n_cores = NULL, boundary = NULL) {
  ensure_sdm_packages("terra", n_cores = n_cores)
  selected_biovars <- validate_biovars(selected_biovars)

  files <- find_worldclim_files(worldclim_dir, selected_biovars)
  if (any(is.na(files)) && allow_download) {
    files <- download_worldclim_layers(worldclim_dir, selected_biovars, worldclim_res, log_fun, n_cores)
  }
  if (any(is.na(files))) {
    missing <- selected_biovars[is.na(files)]
    stop("Missing WorldClim layer(s): ", paste(paste0("BIO", missing), collapse = ", "),
         ". Restore the Worldclim folder or enable Download missing WorldClim layers.", call. = FALSE)
  }

  log_message(log_fun, "Loading ", length(files), " WorldClim layer(s) from ", worldclim_dir)
  terra::terraOptions(memfrac = 0.75, progress = 1)
  env_global <- terra::rast(unname(files))
  names(env_global) <- paste0("bio", selected_biovars)

  list(
    env_train = crop_and_optionally_aggregate(env_global, training_extent, aggregation_factor, NULL),
    env_project = crop_and_optionally_aggregate(env_global, projection_extent, aggregation_factor, NULL),
    selected_biovars = selected_biovars,
    files = files
  )
}

find_cmip6_files <- function(cmip6_dir, selected_biovars, model, ssp, time) {
  if (!dir.exists(cmip6_dir)) return(setNames(rep(NA_character_, length(selected_biovars)), selected_biovars))
  files <- list.files(cmip6_dir, pattern = "\\.tif$", full.names = TRUE, recursive = TRUE)
  selected_biovars <- as.integer(selected_biovars)
  if (length(files) == 0) return(setNames(rep(NA_character_, length(selected_biovars)), selected_biovars))
  time_clean <- gsub("-", "", time)
  matched <- vapply(selected_biovars, function(bv) {
    pattern <- sprintf("bio%d_%s_%s_%s\\.tif$", bv, model, ssp, time_clean)
    hit <- files[grepl(pattern, basename(files), ignore.case = TRUE, perl = TRUE)]
    if (length(hit) == 0) NA_character_ else hit[1]
  }, character(1))
  matched
}

download_cmip6_layers <- function(cmip6_dir, selected_biovars, model = "ACCESS-CM2", ssp = "585",
                                   time = "2061-2080", res = 10, log_fun = NULL, n_cores = NULL) {
  ensure_sdm_packages(c("terra", "geodata"), n_cores = n_cores)
  dir.create(cmip6_dir, recursive = TRUE, showWarnings = FALSE)
  log_message(log_fun, "Downloading CMIP6 future climate to ", cmip6_dir, " (", model, ", SSP", ssp, ", ", time, ")")
  tryCatch({
    wc_future <- geodata::cmip6_world(model = model, ssp = ssp, time = time, var = "bioc", res = res, path = cmip6_dir)
    for (bv in as.integer(selected_biovars)) {
      idx <- grep(sprintf("bio_?%d$", bv), names(wc_future), ignore.case = TRUE)
      if (length(idx) == 0 && bv <= terra::nlyr(wc_future)) idx <- bv
      if (length(idx) > 0) {
        out <- file.path(cmip6_dir, sprintf("bio%d_%s_%s_%s.tif", bv, model, ssp, gsub("-", "", time)))
        if (!file.exists(out)) try(terra::writeRaster(wc_future[[idx[1]]], out, overwrite = TRUE), silent = TRUE)
      }
    }
    invisible(find_cmip6_files(cmip6_dir, selected_biovars, model, ssp, time))
  }, error = function(e) {
    log_message(log_fun, "CMIP6 download failed: ", conditionMessage(e))
    NULL
  })
}

load_future_climate_covariates <- function(cmip6_dir, selected_biovars, projection_extent,
                                            aggregation_factor = 1, allow_download = TRUE,
                                            model = "ACCESS-CM2", ssp = "585", time = "2061-2080",
                                            worldclim_res = 10, log_fun = NULL, n_cores = NULL, boundary = NULL) {
  ensure_sdm_packages("terra", n_cores = n_cores)
  selected_biovars <- validate_biovars(selected_biovars)

  files <- find_cmip6_files(cmip6_dir, selected_biovars, model, ssp, time)
  if (any(is.na(files)) && allow_download) {
    files <- download_cmip6_layers(cmip6_dir, selected_biovars, model, ssp, time, worldclim_res, log_fun, n_cores)
  }
  if (is.null(files) || any(is.na(files))) {
    stop("Missing CMIP6 layer(s). Download failed or files not found in ", cmip6_dir, call. = FALSE)
  }

  log_message(log_fun, "Loading ", length(files), " CMIP6 layer(s) from ", cmip6_dir)
  terra::terraOptions(memfrac = 0.75, progress = 1)
  env_global <- terra::rast(unname(files))
  names(env_global) <- paste0("bio", selected_biovars)

  list(
    env_project = crop_and_optionally_aggregate(env_global, projection_extent, aggregation_factor, boundary),
    selected_biovars = selected_biovars,
    files = files,
    scenario = list(model = model, ssp = ssp, time = time)
  )
}
